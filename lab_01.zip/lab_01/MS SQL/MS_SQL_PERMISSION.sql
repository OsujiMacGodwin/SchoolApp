To see who has explicit insert, update, delete, alter, or control permissions:

SQL
Select P.name As Principal,
	class_desc As PermissionLevel,	permission_name As PermissionGranted,
	ObjectName = Case class When 0 Then DB_NAME()
		When 1 Then OBJECT_SCHEMA_NAME(major_id) + N'.' + OBJECT_NAME(major_id)
		End
From sys.database_permissions As DP
Inner Join sys.database_principals As P On P.principal_id = DP.grantee_principal_id
Where permission_name In ('insert', 'update', 'delete', 'control', 'alter')
And state = 'G'; -- Grant

To see who has built-in role membership that allows write operations:

SQL
Select P1.name As Principal,
	P2.name As DBRole
From sys.database_principals As P1
Inner join sys.database_role_members As RM On RM.member_principal_id = P1.principal_id
Inner join sys.database_principals As P2 On P2.principal_id = RM.role_principal_id
Where P2.name in ('db_owner', 'db_datawriter', 'db_ddladmin');


To see who is the owner (dbo) of the database (has full control):

SQL
Select SUSER_SNAME(owner_sid)
From sys.databases
Where database_id = DB_ID();
To see who has role membership at the server level that gives them write access to the database:

SQL
Select P1.name As Principal,
	P2.name As ServerRole
From sys.server_principals As P1
Inner join sys.server_role_members As RM On RM.member_principal_id = P1.principal_id
Inner join sys.server_principals As P2 On P2.principal_id = RM.role_principal_id
Where P2.name = 'sysadmin';


To see who has permissions granted at the server level that gives them write access to the database:

Select P.name As Principal,
	class_desc As PermissionLevel,
	permission_name As PermissionGranted
From sys.server_permissions As SP
Inner join sys.server_principals As P On P.principal_id = SP.grantee_principal_id
Where permission_name In ('control server', 'alter any database')
And state = 'G'; -- Grant


GRANT UPDATE ON [DeviceFinancing].[dbo].[DeviceRequests] TO "NTNIGE\A247589";
GRANT UPDATE ON [DeviceFinancing].[dbo].[DeviceRequests] TO "NTNIGE\A236247";



GRANT UPDATE ON dbo.DeviceRequests TO "NTNIGE\A239420";
GRANT UPDATE ON dbo.DeviceRequests TO "NTNIGE\A239420";


GRANT UPDATE ON dbo.DeviceRequests TO "NTNIGE\A240942";
GRANT UPDATE ON dbo.DeviceRequests TO "NTNIGE\A240942";


GRANT UPDATE ON dbo.DeviceRequests TO "NTNIGE\A246135";
GRANT UPDATE ON dbo.DeviceRequests TO "NTNIGE\A246135";



USE PaymentProofAutomationDb;   
GRANT EXECUTE ON OBJECT::dbo.InsertTransactionNip  
    TO appsvrusr;  
GO 

GRANT UPDATE ON [dbo].[USSDSessionChargeConsent] TO "NTNIGE\A247591";
GRANT UPDATE ON [dbo].[USSDSessionChargeBatchedConsent] TO "NTNIGE\A247591";
GRANT DELETE ON [dbo].[USSDSessionChargeBatchedConsent] TO "NTNIGE\A247591";