USE [master]
GO

/****** Object:  DdlTrigger [TrackUserLogin]    Script Date: 9/18/2024 5:16:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

 
CREATE TRIGGER [TrackUserLogin]
ON ALL SERVER
WITH EXECUTE AS 'alwayson'
FOR LOGON
AS
BEGIN
    DECLARE @UserName NVARCHAR(128) = ORIGINAL_LOGIN();
    
    IF EXISTS (SELECT 1 FROM UserLoginTracking WHERE UserName = @UserName)
    BEGIN
        UPDATE UserLoginTracking
        SET LastLoginDate = GETDATE()
        WHERE UserName = @UserName;
    END
    ELSE
    BEGIN
        INSERT INTO UserLoginTracking (UserName, LastLoginDate)
        VALUES (@UserName, GETDATE());
    END
END;
 
ENABLE TRIGGER [TrackUserLogin] ON ALL SERVER
GO


