USE [master]
GO

/****** Object:  Table [dbo].[UserLoginTracking]    Script Date: 9/18/2024 5:42:25 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[UserLoginTracking](
	[UserName] [nvarchar](128) NOT NULL,
	[LastLoginDate] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[UserName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

USE [master]
GO

/****** Object:  View [dbo].[vUserLoginTracking]    Script Date: 12/5/2024 2:37:10 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

 CREATE VIEW [dbo].[vUserLoginTracking] as	
		SELECT a.UserName, a.LastLoginDate
        FROM UserLoginTracking a
		WHERE a.UserName like 'NTNIGE\A%'
		UNION ALL
        SELECT b.UserName, b.LastLoginDate
        FROM UserLoginTracking b
		WHERE b.UserName like 'NTNIGE\EA%'	
		and b.UserName not in ('NTNIGE\EA251651T1','NTNIGE\EA250089T1','NTNIGE\EA246458T1','NTNIGE\EA255207T1','NTNIGE\EA251929T1');
GO



INSERT INTO [master].[dbo].[UserLoginTracking]
select loginname, GETDATE() from sys.syslogins
where denylogin = '0' and  name like 'NTNIGE\A%'  and 
name not in (select UserName from [dbo].[UserLoginTracking])
UNION ALL
select loginname, GETDATE() from sys.syslogins
where denylogin = '0' and
name like 'NTNIGE\EA%' and name not in (select UserName from [dbo].[UserLoginTracking])
