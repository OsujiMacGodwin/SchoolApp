. /home/oracle/.profile
DIR_LOC="/home/oracle/automation/space_usage"
today=$(date)

echo "To:dba@ubagroup.com
Subject:Oracle Database Growth on $ORACLE_SID as at $today
From: PROD_F10_Nig_DB@ubagroup.com
Content-Type: text/html
<html>
<head>
<style>
table {
  border-collapse: collapse;
  /*width: 100%;*/
  border: 0px solid #000;
}
th, td {
  text-align: left;
  padding: 8px;
}
th {
  background: #E30F00;
  color: #fff;
}
tr:nth-child(even) {background-color: #999;}
</style>
</head>
<body>
<br/>Dear Team,<br/>Please find below attached oracle database growth on $ORACLE_SID as at $today<br/><br/>
<div style='overflow-x:auto;'>
<table><tr><th> Database </th><th> Prior Week Date</th><th> Prior Week Size (GB) </th><th> Current Date </th><th> Current Size (GB) </th><th> Growth (GB) </th></tr>" > $DIR_LOC/email.txt

sqlplus -s "/as sysdba" << !
alter session set nls_date_format='DD-MON-YYYY';
set feed off 
set linesize 150
set pagesize 0
spool growthreport_tmp
select '<tr><td> ' ||db_sid ||' </td><td> ' ||min(rcre_date)||' </td><td> ' || min(N_db_used)||' </td><td> ' ||max(rcre_date)
||' </td><td> ' ||max(N_db_used)||' </td><td> ' ||(max(N_db_used) - min(N_db_used) ) || ' </td></tr> '
from 
(select db_sid, rcre_date, N_db_used
from daily_db_stats where trunc(rcre_date) in (trunc(sysdate-7), trunc(sysdate))) group by db_sid;
spool off
exit
!

if [ `cat growthreport_tmp.lst|wc -l` -gt 0 ]
then
cat growthreport_tmp.lst >> $DIR_LOC/email.txt
echo '<!--<tr>
      <th colspan="6">&nbsp</th>
    </tr>--></table> <br/><br/> Details of Growth
	<table><tr><th> Database </th><th> Database Size (GB) </th><th> Used Space (GB)</th><th> Space Remaining </th><th> Time Taken </th></tr>
	' >> $DIR_LOC/email.txt

	
sqlplus -s "/as sysdba" << !
alter session set nls_date_format='DD-MON-YYY HH24:MI:SS';
set feed off
set linesize 150
set pagesize 0
spool growthreport_det_tmp

select '<tr><td> ' ||db_sid ||' </td><td> ' || n_db_size||' </td><td> ' || n_db_used||' </td><td> ' ||(n_db_size - n_db_used) ||' </td><td> ' ||to_char(rcre_date,'DD-MON-RRRR HH24:MI:SS') ||' </td></tr> ' from 
daily_db_stats where trunc(rcre_date) between trunc(sysdate-7) and trunc(sysdate)
order by rcre_date desc;
spool off
exit
!
cat growthreport_det_tmp.lst >> $DIR_LOC/email.txt
echo '<!--<tr>
      <th colspan="5">&nbsp</th>
    </tr>--></table> <br/><br/> List of DataFiles Added in 7 Days

<table><tr><th> Tablespace Name </th><th> Database File</th><th> Date Added </th><th> Size (GB) </th></tr>
	' >> $DIR_LOC/email.txt	

####
sqlplus -s "/as sysdba" << !
@$DIR_LOC/sql3.sql
exit
!
cat growthreport2_det_tmp.lst >> $DIR_LOC/email.txt
echo '<!--<tr>
      <th colspan="5">&nbsp</th>
    </tr>--></table> <br/><br/>
        ' >> $DIR_LOC/email.txt
###
( cat $DIR_LOC/email.txt
 echo '<br/></body></html>') | /usr/sbin/sendmail -t
		

		
fi	




