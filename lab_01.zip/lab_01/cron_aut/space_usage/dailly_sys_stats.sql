set echo off
set feedback off
set termout off
set verify off
set serveroutput on size 1000000
spo daily_update
DECLARE
         cursor stats_cur IS
         select    round(sum(used.bytes) / 1024 / 1024 / 1024 ) AB
         ,round(sum(used.bytes) / 1024 / 1024/1024 )- round(free.p / 1024 / 1024 / 1024) AA
         ,round(free.p / 1024 / 1024 / 1024) AC
         from    (select bytes from v$datafile union all select bytes from v$tempfile union all select bytes from v$log) used
         ,(select sum(bytes) as p
         from dba_free_space) free
         group by free.p;


--VARIABLES
n_reccount                                      number :=0;
n_db_free                                         number;
n_db_free1                                        number :=0;
n_db_size                                         number;
n_db_used                                        number :=0;



BEGIN


OPEN stats_cur; --[
LOOP --{

FETCH stats_cur into

n_db_size,n_db_used,n_db_free;

EXIT when stats_cur%notfound;

begin
        insert into daily_db_stats (db_sid,n_db_size,n_db_used,n_db_free,rcre_date,del_flg)
        values ('UBANG',n_db_size,n_db_used,n_db_free,sysdate,'N');
        dbms_output.put_line ('The UBADB datafiles usage has been run '||n_db_free||' GB free and used '||n_db_used);
        commit;
end;
END LOOP;
END;
/
spo off
exit
