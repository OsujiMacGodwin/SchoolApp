alter session set nls_date_format='DD-MON-YYY HH24:MI:SS';
set feed off
set define off
set linesize 150
set pagesize 0
spool growthreport2_det_tmp
select '<tr><td> ' ||vt.name ||' </td><td> ' || vd.name ||' </td><td> ' || to_char(creation_time,'DD-MON-RRRR HH24:MI:SS') 
||' </td><td> ' || (bytes /1024/1024/1024) ||' </td></tr> ' 
from v$datafile vd, v$tablespace vt where trunc(vd.creation_time) between trunc(sysdate-7) and
trunc(sysdate)
and vd.ts# = vt.ts#
 order by creation_time desc;
spool off
