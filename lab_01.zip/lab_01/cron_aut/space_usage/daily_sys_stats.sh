#!/bin/ksh
#spool Bank_Conc_Users

HOSTNAME=`hostname`
export ORACLE_SID=UBANG
export ORACLE_HOME=/oracledb11/app/oracle11R2/product/11.2
PATH=$PATH:$ORACLE_HOME/bin
export TNS_ADMIN=$ORACLE_HOME/network/admin/rman

sqlplus -s /nolog << !
conn / as sysdba

@/finbackup/script/db_stats/dailly_sys_stats.sql

spool off

exit

!

