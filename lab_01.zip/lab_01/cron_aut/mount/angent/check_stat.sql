insert into rmanmgr.mount_point_stats values ('PROD_F10_Nig_DB','UBANG','/finarch',sysdate,'3800.00','2661.47','30','70');
insert into rmanmgr.mount_point_stats values ('PROD_F10_Nig_DB','UBANG','/oracledb11',sysdate,'60.00','38.51','36','64');
commit;
exit;
