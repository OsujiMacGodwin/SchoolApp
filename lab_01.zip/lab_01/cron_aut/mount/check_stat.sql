insert into DUKNIMA06098.mount_point_stats values ('/finarch',sysdate,'3800.00','2743.17','28','72');
insert into DUKNIMA06098.mount_point_stats values ('/oracledb11',sysdate,'60.00','38.51','36','64');
commit;
exit;
