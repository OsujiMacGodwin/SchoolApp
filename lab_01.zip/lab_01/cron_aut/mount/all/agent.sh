. /home/oracle/.profile
hostname=/usr/bin/hostname
export dbname="UBANG"
rm /home/oracle/automation/rpt/allmountpoint/check_stat.sql
df -gs | awk '{print "insert into rmanmgr.all_mount_point_stats values (q'PROD_F10_Nig_DB'q,q'UBANG'q,q"$7"q,sysdate,q"$2 "q,q" $3 "q,q" $4 "q,q" 100 - $4"%q);"}' | grep -v "GB" | sed "s/q/'/g" | sed "s/%//g" > /home/oracle/automation/rpt/allmountpoint/check_stat.sql
echo 'commit;' >> /home/oracle/automation/rpt/allmountpoint/check_stat.sql
echo 'exit;' >> /home/oracle/automation/rpt/allmountpoint/check_stat.sql
sqlplus -s 'dbsnmp/sys_dbsnmp$123@ubarepos' @/home/oracle/automation/rpt/allmountpoint/check_stat.sql
