export ORACLE_HOME=/oracledb11/app/oracle11R2/product/11.2
export PATH=$ORACLE_HOME/bin:$PATH
export ORACLE_SID=UBANG
export TNS_ADMIN=$ORACLE_HOME/network/admin/rman
TBS_USAGE="/home/oracle/automation/tablespace_usage"
Threshold=80
DDD=$(date)


echo "To: dba@ubagroup.com
Subject: Tablespace statistics on $ORACLE_SID that are greater than $Threshold% as at $DDD   
From: PROD_F10_Nig_DB@ubagroup.com
Content-Type: text/html

<html>
<head>
<title>Status of the jobs during the day</title>
<style>
table, th, td {
    border: 1px solid blue;
    border-collapse: collapse;
}
th, td {
    padding: 5px;
}
</style>
</head>
<body>
Dear Team,<br/>Please find below the tablespace usage statistics for $ORACLE_SID<br/><br/>
<table style='width:100%'><tr><th> TABLESPACE NAME </th><th> TOTAL BYTES </th><th> TOTAL USED </th><th> TOTAL FREE </th><th> PERCENTAGE USED </th></tr>" > header.txt 


sqlplus -s "/as sysdba" << !
set feed off
set linesize 150
set pagesize 0
spool tablespace.stats.2

select '<tr><td>' || bb.TABLESPACE_NAME ||'</td><td>'|| 
case when bb.tot_bytes > 1 then round(bb.tot_bytes,2) || ' GB' else round(bb.tot_bytes * 1024,2) || ' MB' end ||'</td><td>'||
case when (bb.tot_bytes - aa.tot_used) > 1 then round(bb.tot_bytes - aa.tot_used,2) || ' GB' else round((bb.tot_bytes - aa.tot_used) * 1024,2) || ' MB' end  ||'</td><td>'||
case when aa.tot_used > 1 then round(aa.tot_used,2) || ' GB'  else round(aa.tot_used * 1024,2) || ' MB' end  ||'</td><td>'||
 round((bb.tot_bytes-aa.tot_used)/bb.tot_bytes*100,2) || '%'  ||'</td></tr>'
 from
(select tablespace_name, sum(bytes)/1073741824 tot_bytes,sum(blocks)/1073741824 tot_blocks,
sum(maxbytes)/1073741824 tot_maxbytes, sum(maxblocks)/1073741824 tot_maxblocks,
 sum(user_bytes)/1073741824 tot_user_bytes,  sum(user_blocks)/1073741824 tot_user_blocks
 from dba_data_files
group by tablespace_name) bb,
(select tablespace_name, sum(bytes)/1073741824 tot_used
       from dba_free_space
       group by tablespace_name) aa
       where aa.tablespace_name=bb.tablespace_name
       and (bb.tot_bytes-aa.tot_used)/bb.tot_bytes*100 > $Threshold
       order by (bb.tot_bytes-aa.tot_used)/bb.tot_bytes desc;

spool off

exit

!

if [ `cat tablespace.stats.2|wc -l` -gt 0 ]
then
cat header.txt > /home/oracle/automation/tablespace_usage/header.txt
cat tablespace.stats.2  | grep -v "CASEWHENBB.TOT_BYTES" > /home/oracle/automation/tablespace_usage/tablespace.stats



( cat /home/oracle/automation/tablespace_usage/header.txt 
 cat /home/oracle/automation/tablespace_usage/tablespace.stats
 echo '</table></body></html>') | /usr/sbin/sendmail -t

fi
