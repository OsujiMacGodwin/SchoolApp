set lines 150
set pages 150
col p1text format a20
col p2text format a20
col p3text format a20
col event format a20
col name format a20
select sw.sid,sw.p1,sw.p1text,sw.p2,sw.p2text,sw.p3,sw.p3text ,sw.event,l.name,s.sql_hash_value,s.prev_sql_Addr,s.machine,s.program from v$session_wait sw,v$latchname l,v$session s 
where event = 'latch free' and sw.p2=l.latch# and sw.sid=s.sid
