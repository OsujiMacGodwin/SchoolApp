#!/bin/ksh
HOSTNAME=`hostname`
export ORACLE_SID=UBANG
export ORACLE_HOME=/oracledb11/app/oracle11R2/product/11.2
PATH=$PATH:$ORACLE_HOME/bin
RTT="/finbackup/script/db_stats/RTT"
>rtt.log
sqlplus -s "/ as sysdba" << !
set linesize 100
set pagesize 2
set NUMFORMAT 999,999,999
spool rtt.log
select count(1) from tbaadm.rtt;
spool off

exit
!
>$RTT
cat rtt.log> $RTT
echo "RTT table record count `date`." >> $RTT
mail -u PROD_F10_Nig_DB@ubagroup.com -s "RTT TABLE RECORD COUNT IN  $ORACLE_SID of $HOSTNAME " dba@ubagroup.com <$RTT

