#!/bin/ksh
HOSTNAME=`hostname`
export ORACLE_SID=UBANG
export ORACLE_HOME=/oracledb11/app/oracle11R2/product/11.2
PATH=$PATH:$ORACLE_HOME/bin
UBANG="/finbackup/script/db_stats/ALERT_UBANG"
>UBANG.log
sqlplus -s "/ as sysdba" << !
set linesize 100
set pagesize 2
set NUMFORMAT 999,999,999
spool UBANG.log
select alert_date, alert_text from duknima06098.alert_log where alert_date >= sysdate-1/24;
spool off

exit
!
>$UBANG_LOG
cat UBANG.log> $UBANG
echo "UBANG DATABASE ALERT LOG ERROR `date`." >> $UBANG
#mail -s "UBANG DATABASE ALERT LOG ERROR  $ORACLE_SID of $HOSTNAME " dba@ubagroup.com <$UBANG
mail -s "UBANG DATABASE ALERT LOG ERROR  $ORACLE_SID of $HOSTNAME " nimiteym.duke@ubagroup.com <$UBANG
