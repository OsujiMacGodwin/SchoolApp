#!/bin/ksh
HOSTNAME=`hostname`
export ORACLE_SID=UBANG
export ORACLE_HOME=/oracledb11/app/oracle11R2/product/11.2
PATH=$PATH:$ORACLE_HOME/bin
export TNS_ADMIN=$ORACLE_HOME/network/admin/rman
REPT="/finbackup/script/db_stats/REPT"
>reptalert.log
sqlplus -s "/ as sysdba" << !
set linesize 100
set pagesize 2
set NUMFORMAT 999,999,999
spool reptalert.log
select count(1) from ALERTUSER.REALTIME_PUBLISH_TABLE;
spool off

exit
!
>$REPT
cat reptalert.log> $REPT
echo "REPT table record count `date`." >> $REPT
/bin/mail -s "REPT TABLE RECORD COUNT IN $ORACLE_SID of $HOSTNAME " dba@ubagroup.com ,UBAMobileBanking@ubagroup.com <$REPT
