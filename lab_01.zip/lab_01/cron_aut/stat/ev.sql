set pages 0
select s.sid,s.program,s.machine,sw.state,sw.wait_time,sa.sql_text,s.process,s.osuser,s.sql_hash_value from v$session s,v$session_wait sw,v$sqlarea sa where sw.sid=s.sid(+) and s.sql_Address=sa.address and sw.event = '&1' order by sw.seconds_in_wait desc 
/

