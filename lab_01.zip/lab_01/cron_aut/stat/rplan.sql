
col object_name format a30
col options format a25
col operation format a20
col dep format a10
set lines 150
set pages 150
select lpad(depth,depth) as dep,operation,options,object_name,cardinality,cost from v$sql_plan where hash_value = '&1';

