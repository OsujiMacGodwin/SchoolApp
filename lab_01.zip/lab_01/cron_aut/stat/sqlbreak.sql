select a.sid,a.program,a.machine,a.prev_hash_value,a.sql_hash_value from v$session a, v$session_Wait b where a.sid = b.sid and b.event = 'SQL*Net break/reset to client'
