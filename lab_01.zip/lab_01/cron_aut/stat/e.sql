select event,count(1) from v$session_wait where event not like 'Stream%' group by event order by 2
/
select * from v$sgastat where name like 'free%'
/
select count(1) from upr where user_logged_on_flg = 'Y'
/

