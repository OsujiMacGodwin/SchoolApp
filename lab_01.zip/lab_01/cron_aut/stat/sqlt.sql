select sql_text,piece from v$sqltext where hash_value= '&1' order by piece asc;
