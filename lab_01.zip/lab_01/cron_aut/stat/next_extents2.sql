
SELECT    /*+ RULE */ 
          SEG.tablespace_name "Tablespace",
          SEG.segment_type "SegmentType",
          EXT.OWNER,
          EXT.segment_name "Segment",
          decode(freespace.Extent_Management,'DICTIONARY',SEG.next_extent,'LOCAL',decode(freespace.Allocation_Type,'UNIFORM',freespace.INITIAL_EXTENT,'SYSTEM',EXT.bytes))/1024 as "Required Extent(KB)",
          freespace.largest/1024 "MaxAvail(KB)"
FROM      DBA_EXTENTS EXT,DBA_SEGMENTS SEG,
         (
           Select     /*+ RULE */ 
                     MaxSize_PerFile.Tablespace_name, TBS.Extent_Management, TBS.Allocation_Type, TBS.INITIAL_EXTENT,
                     TBS.NEXT_EXTENT, Max(MaxSize_PerFile.MaxSizeBytes) As Largest
           FROM
               (
                  SELECT     /*+ RULE */ 
                             DDF.TABLESPACE_NAME, DDF.File_Id,
                             decode(AUTOEXTENSIBLE,'YES',(DDF.MAXBYTES-DDF.BYTES),0) + Nvl(Max (DFS.bytes ),0) as MaxSizeBytes, 
                      Nvl(Max (DFS.bytes ),0) as MaxFreeExtentSizeBytes
                  FROM       Dba_Free_Space DFS, DBA_DATA_FILES DDF , DBA_TABLESPACES TBSP
                  WHERE      DFS.File_Id (+)            = DDF.File_Id
                  AND        TBSP.Tablespace_Name       = DDF.TABLESPACE_NAME
                  AND        TBSP.CONTENTS              = 'PERMANENT'
                  AND        TBSP.STATUS                = 'ONLINE'
                  Group By   DDF.TABLESPACE_NAME, DDF.File_Id,decode(AUTOEXTENSIBLE,'YES',(DDF.MAXBYTES-DDF.BYTES),0)
               )   MaxSize_PerFile, dba_tablespaces TBS
          WHERE    MaxSize_PerFile.Tablespace_Name      = TBS.Tablespace_Name
          AND      TBS.Status                           = 'ONLINE'
          GROUP BY MaxSize_PerFile.Tablespace_Name, TBS.Extent_Management, TBS.Allocation_Type, 
                   TBS.INITIAL_EXTENT, TBS.NEXT_EXTENT
        ) FREESPACE
WHERE
        SEG.owner            =     EXT.owner 
AND     SEG.segment_type     =     EXT.segment_type 
AND     SEG.segment_name     =     EXT.segment_name 
AND     SEG.tablespace_name  =     EXT.tablespace_name 
AND    (SEG.extents-1)       =     EXT.extent_id 
AND    SEG.tablespace_name   =     FREESPACE.tablespace_name
AND    decode(freespace.Extent_Management,'DICTIONARY',
       decode(SEG.extents,1,(SEG.next_extent),ext.bytes*(1+SEG.pct_increase/100))
       ,'LOCAL',decode(freespace.Allocation_Type,'UNIFORM',freespace.INITIAL_EXTENT,'SYSTEM',EXT.bytes)) > freespace.largest
ORDER BY SEG.Tablespace_Name,SEG.Segment_Type,SEG.Segment_Name
/
