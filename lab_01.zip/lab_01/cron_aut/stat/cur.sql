set pages 200
set lines 145
col program format a30
col osuser format a15
select sess.sid,substr(sess.program,1,22) as program,sw.event,sess.osuser,sql.hash_value,sql.buffer_gets/sql.executions as buf_gets_per,sql.executions from v$session sess , v$sqlarea sql ,v$session_wait sw where sess.sql_Address=sql.address and sw.sid=sess.sid and sess.status = 'ACTIVE' and sql.buffer_gets > 100 and sql.disk_reads > 10 and sql.executions > 0 order by sql.buffer_gets/sql.executions;
