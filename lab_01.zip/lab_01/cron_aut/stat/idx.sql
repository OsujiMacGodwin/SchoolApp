set lines 150
set pages 150
col index_name format a30
col column_name format a30
select a.index_name,a.column_name,a.column_position,b.uniqueness from dba_ind_columns a,dba_indexes b where a.table_name = '&1' and a.index_name=b.index_name order by index_name,column_position;

