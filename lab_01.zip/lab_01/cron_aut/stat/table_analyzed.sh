#!/bin/ksh
export ORACLE_HOME=/oracledb/oracle925
export PATH=$ORACLE_HOME/bin:$PATH
export TNS_ADMIN=$ORACLE_HOME/network/admin/rman
export ORACLE_SID=UBADB
TBL_ANALYZE="/home/oracle/tbl_analyze"
Threshold=3
sqlplus -s "dbsnmp/sys_dbsnmp123" << !
set feed off
set linesize 300
set pagesize 400
/*COLUMN table_name heading object 
COLUMN object format A90
COLUMN num_rows format 999,999,999,999
COLUMN last_analyzed format A100
*/
COLUMN last_analyzed format A200
set wrap off
spool tables_stats.alert
select rpad(table_name,90)||num_rows||'      '|| to_char(last_analyzed,'DD-MM-YYYY HH:MI') last_analyzed from dba_tables where table_name in ('AUDIT_TABLE','CHRG_TRAN_LOG_TBL',
'CUST_MAST_GEN_TABLE','DAILY_TRAN_DETAIL_TABLE','DAILY_TRAN_HEADER_TABLE','EOD_TRAN_DETAIL_TABLE','EOD_TRAN_HEADER_TABLE','GENERAL_ACCT_MAST_TABLE','HIST_TRAN_DTL_TABLE','HIST_TRAN_HEADER_TABLE','IMAGE_TABLE','INTEREST_DETAILS_TABLE','REF_TRN_TBL','TEMP_DAILY_TRAN_TABLE','A
LERT_SUBSCRIPTION_TABLE','REALTIME_PUBLISH_TABLE','CUS_E_ALERT_TBL')
union all
select rpad(table_name||' index is: '||index_name,90)||num_rows||'      '||to_char(last_analyzed,'DD-MM-YYYY HH:MI') last_analyzed from dba_indexes where table_name in ('AUDIT_TABLE','CHRG_TRAN_LOG_TBL',
'CUST_MAST_GEN_TABLE','DAILY_TRAN_DETAIL_TABLE','DAILY_TRAN_HEADER_TABLE','EOD_TRAN_DETAIL_TABLE','EOD_TRAN_HEADER_TABLE','GENERAL_ACCT_MAST_TABLE','HIST_TRAN_DTL_TABLE','HIST_TRAN_HEADER_TABLE','IMAGE_TABLE','INTEREST_DETAILS_TABLE','REF_TRN_TBL','TEMP_DAILY_TRAN_TABLE','ALERT_SUBSCRIPTION_TABLE','REALTIME_PUBLISH_TABLE','CUS_E_ALERT_TBL');
spool off


exit

!
>$TBL_ANALYZE
cat tables_stats.alert  > $TBL_ANALYZE
/bin/mail -s "TABLE AND INDEX ANALYZED STATUS ON $ORACLE_SID  " dba@ubagroup.com,osilama.idokogi@ubagroup.com  < $TBL_ANALYZE
