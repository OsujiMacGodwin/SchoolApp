col data_type format a20
select COLUMN_NAME,DATA_TYPE,NUM_DISTINCT,NUM_NULLS,NUM_BUCKETS from dba_tab_cols where table_name ='&1';
