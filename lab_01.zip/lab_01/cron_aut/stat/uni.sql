set lines 150
set pages 150
column machine format a20
column event format a30
select a.program,b.event,a.machine,a.prev_hash_value,a.sql_hash_value,a.prev_sql_addr from v$session a, v$session_wait b where a.sid=b.sid and a.program like '%uni%' group by a.program,b.event,a.machine,a.prev_hash_value,a.sql_hash_value,a.prev_sql_addr;
