. /home/oracle/.profile
hostname=/usr/bin/hostname
export dbname="UBANG"
dirname = "/home/oracle/automation/dataguard/m1/"
sqlplus -s "/as sysdba" << !
set feed off
set define off
set pagesize 0
alter session set nls_date_format='DD-MON-YYYY HH24 MI SS';
spool /home/oracle/automation/dataguard/m1/dataguard.sql
set define off;
@/home/oracle/automation/dataguard/m1/dynamic.sql
spool off

exit
!

if [ `cat /home/oracle/automation/dataguard/m1/dataguard.sql | grep insert | wc -l` -gt 0 ]
then

echo 'commit;' >> /home/oracle/automation/dataguard/m1/dataguard.sql
echo 'exit;' >> /home/oracle/automation/dataguard/m1/dataguard.sql
sqlplus -s 'dbsnmp/sys_dbsnmp$123@ubarepos' @/home/oracle/automation/dataguard/m1/dataguard.sql 
fi
