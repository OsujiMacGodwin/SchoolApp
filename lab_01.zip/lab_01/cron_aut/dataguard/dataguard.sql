insert into RMANMGR.XX_DATAGUARD_STATUS values ('PROD_F10_Nig_DB','UBANG',      
'PRIMARY','READ WRITE','ARCHIVELOG',sysdate,                                    
to_date('11-JAN-2023 07 04 59','DD-MON-YYYY HH24 MI SS'),sysdate,'423547'       
,'');                                                                           
                                                                                
commit;
exit;
