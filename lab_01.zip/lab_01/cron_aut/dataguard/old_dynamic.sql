select UTL_INADDR.get_host_name||''','''||name||''','''||
database_role||''','''||open_mode||''','''||log_mode||''',sysdate,'''||
controlfile_time||''','','||
(select max(sequence#) from v$archived_log where dest_id=1)||''','''||
  (select wm_concat( destination || ' '|| status ||' '|| error)  from gv$archive_dest where error is not null)||''','
||');' dynamics from v$database;
