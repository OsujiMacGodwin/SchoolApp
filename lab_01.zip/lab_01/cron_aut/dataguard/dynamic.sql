select 'insert into RMANMGR.XX_DATAGUARD_STATUS values ('''||UTL_INADDR.get_host_name||''','''||name||chr(39)||',',
chr(39)||database_role||''','''||open_mode||''','''||log_mode||''',sysdate'||',',
'to_date('||chr(39)||controlfile_time||''','||'''DD-MON-YYYY HH24 MI SS'||'''),sysdate,'''||(select max(sequence#) from gv$archived_log where dest_id=1)||chr(39),','||
chr(39)|| (select wm_concat( destination || ' '|| status ||' '|| error) errors from gv$archive_dest where error is not null)||''');' from v$database;
