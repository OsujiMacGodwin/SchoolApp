CREATE OR REPLACE PROCEDURE RPT_LN_INSTMNT_PMNT_ANALYSIS_SP
    (advice_cursor IN OUT Supernova_Package.ref_cursor,
     i_acct_no       IN loan_account_summary.acct_no%TYPE,
     request_mode  IN VARCHAR2) AS
 
  v_sql_text              VARCHAR2(10000);
  v_sql_subquery_acct_no   VARCHAR2(100);

BEGIN
  
 SELECT DECODE(i_acct_no, NULL, ' ', ' and A.ACCT_NO = ' || i_acct_no)
    INTO v_sql_subquery_acct_no
    FROM DUAL;
     
 v_sql_text :=
      ' select A.ACCT_NO,
B.CUST_NM,
C.LAST_DISBURSEMENT_DT,
D.MATURITY_DT,
A.STATUS_EFFECTIVE_DT,
D.TERM_VALUE || '' '' ||decode(D.TERM_CD, ''M'', ''(Months)'', ''W'', ''(Weeks)'' ) as Term,
decode(A.REC_ST, ''A'', ''ACCOUNT ACTIVE'', ''L'', ''ACCOUNT CLOSED'', ''I'', ''ACCOUNT INACTIVE'', ''N'', ''NON-ACCRUAL'', ''Q'', ''DELINQUENT'', ''C'', ''ACCOUNT CANCELLED'', ''W'', ''ACCOUNT WRITTEN-OFF'',
''M'', ''MATURED'', ''B'', ''BAD DEBT'' ) as "Account Status",
(select sys.first_nm || '' '' || sys.last_nm from sysuser sys where sys.sysuser_id = d.primary_officer_id) As "Account R/Officer",
p.DUE_DT as Due_Date,
p.SVCE_DT as Payment_dt, 
p.arrear_days as Arrear_days,
(select param_value from ctrl_parameter where param_cd = ''S04'') as Bank_name
from account a, customer b, loan_account_summary c, loan_account d, 
(select z.acct_id, z.due_dt as due_dt, max(z.svce_dt) svce_dt,  
      max(z.svce_dt) - z.due_dt as arrear_days
from LN_ACCT_REPMNT_EVENT z, ctrl_parameter x
where z.rec_st in (''N'',''P'',''S'',''H'')
and x.param_cd = ''S02''
and Z.EVENT_TYPE IN (''PRINCIPAL'', ''INTEREST'')
group by z.acct_id, z.due_dt
order by 1, 2) p
where A.CUST_ID = B.CUST_ID
'||v_sql_subquery_acct_no||'
and A.ACCT_ID = D.ACCT_ID
and D.CUST_ID = B.CUST_ID
and C.ACCT_ID = A.ACCT_ID
and D.ACCT_ID = C.ACCT_ID
and P.ACCT_ID = D.ACCT_ID
--and c.ACCT_no = 1000020029
order by 1, 9, 10
';
OPEN advice_cursor FOR v_sql_text;
--dbms_output.put_line(v_sql_text);
END; 
/
