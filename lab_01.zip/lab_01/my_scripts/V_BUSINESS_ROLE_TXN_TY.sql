CREATE OR REPLACE VIEW V_BUSINESS_ROLE_TXN_TY AS
SELECT T2.EVENT_ID,
          T1.CHANNEL_DESC,
          T2.EVENT_DESC,
          T3.PREVENTIVE_LIMIT,
          T3.CRNCY_ID,
          T5.CRNCY_CD_ISO,
          T3.BUS_ROLE_TRAN_TY_ID,
          T3.BUS_ROLE_ID,
          T3.PRECAUTIONARY_LIMIT,
          T2.EVENT_CD,
          T4.EVENT_CHANNEL_ID,
          T4.CHANNEL_ID,
          T3.CREATED_BY,
          T3.CREATE_DT,
          T3.SYS_CREATE_TS,
          T3.USER_ID,
          T3.ROW_TS,
          T3.VERSION_NO,
          T3.REC_ST,
          T2.SYS_TYPE_FG,
          T2.TRAN_CLASS_CD,
          T2.SCREEN_CD,
          T2.DRCR_FG,
          T2.PROCESS_CAT_CD,
          T2.PROD_CAT_TY,
          T2.SERVICE_CAT_CD,
          T2.TRAN_TEMPLATE_ID,
          T2.URI,
          T2.GEN_TEMPLATE_FG
     FROM SERVICE_CHANNEL T1,
          V_TXN_TYPES T2,
          BUSINESS_ROLE_TRAN_TY T3,
          EVENT_CHANNEL T4,
          CURRENCY T5
    WHERE     T3.EVENT_CHANNEL_ID = T4.EVENT_CHANNEL_ID
          AND T4.EVENT_ID = T2.EVENT_ID
          AND T4.CHANNEL_ID = T1.CHANNEL_ID
          AND T3.CRNCY_ID = T5.CRNCY_ID
          AND T2.REC_ST = 'A';
