select C.COD_CUST,
       OB.ACCT_NO "ORBIT_R ACCT_NO",
       C.COD_ACCT_NO,
       C.DAT_ACCT_OPEN,
       (case
         when C.DAT_LAST_DR > C.DAT_LAST_CR then
          C.DAT_LAST_DR
         when C.DAT_LAST_CR > C.DAT_LAST_DR then
          C.DAT_LAST_CR
         when C.DAT_LAST_CR = C.DAT_LAST_DR then
          C.DAT_LAST_DR
         else
          NULL
       end) as LAST_TNX_DAY,
       ((case
         when C.DAT_LAST_DR > C.DAT_LAST_CR then
          C.DAT_LAST_DR
         when C.DAT_LAST_CR > C.DAT_LAST_DR then
          C.DAT_LAST_CR
         when C.DAT_LAST_CR = C.DAT_LAST_DR then
          C.DAT_LAST_DR
         else
          NULL
       end) + 180) as "DORMANT_DAY"
  from ch_acct_mast@host_link C
  left join (select DB.ACCT_NO ,EX.OLD_ACCT_NO, EX.ACCT_NM, EX.INT_ACCT_ID 
               from fincalive.Deposit_account@orb_link DB  right join fincalive.ext_account@orb_link EX on DB.ACCT_ID = EX.INT_ACCT_ID 
              where EX.PROD_CAT_TY = 'DP') OB
    on trim(OB.OLD_ACCT_NO) = trim(C.COD_ACCT_NO)
 where C.COD_PROD in (select COD_PROD from ch_prod_mast@host_link)
   and C.COD_ACCT_STAT in (select COD_ACCT_STATUS
                             from ba_acct_status
                            where TXT_ACCT_STATUS like '%DORMANT%'
                              and COD_MODULE = 'CH')
    order by C.DAT_ACCT_OPEN desc  