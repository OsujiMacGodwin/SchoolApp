with tbl_ln_arreas as
 (select acct_id, principal, interest, charge
    from (select acct_id, event_type, amt_unpaid
            from ln_acct_repmnt_event
           where due_dt <= trunc(sysdate)
             and rec_st not in ('C')) pivot(sum(amt_unpaid) for event_type in('PRINCIPAL'
                                                                              PRINCIPAL,
                                                                              'INTEREST'
                                                                              INTEREST,
                                                                              'CHARGE'
                                                                              CHARGE))),
tbl_cust_contacts as
 (SELECT *
    FROM (select B.CONTACT_MODE_TY, A.CUST_ID, CONTACT
            from CUSTOMER_CONTACT_MODE A
            JOIN CONTACT_MODE_REF B
              ON B.CONTACT_MODE_ID = A.CONTACT_MODE_ID) PIVOT(MAX(CONTACT) FOR CONTACT_MODE_TY IN(100
                                                                                                  HomePhone,
                                                                                                  200
                                                                                                  OfficeFax,
                                                                                                  400
                                                                                                  Office_EMail,
                                                                                                  500
                                                                                                  Personal_EMail,
                                                                                                  600
                                                                                                  OfficePhone,
                                                                                                  700
                                                                                                  Mobile))),
tbl_passive_svs as
 (select *
    from (select cust_id, prod_cat_ty, a.acct_id
            from account a
            join (select acct_id
                   from account
                  where prod_cat_ty != 'LN'
                 minus
                 select principal_setlmnt_acct_id
                   from loan_account_disbursement) b
              on a.acct_id = b.acct_id
           where a.rec_st not in ('L', 'I', 'S')) pivot(count(acct_id) for prod_cat_ty in('DP' DP,
                                                                                          'TDEP' TDEP))),
tbl_ln_dtls as
 (select a.cust_id,
         a.acct_id,
         a.acct_no,
         b.ledger_bal,
         b.dr_int_accrued,
         b.last_payment_dt,
         b.next_payment_dt, /*(case when c.rec_st = 'L' then 0 else nvl(trunc(sysdate)-b.delinquent_dt,0) end) DAYS_ARREARS*/
         TAD.arrear_days as "DAYS_ARREARS",
         a.loan_cycle,
         c.rec_st,
         a.closed_dt,
         a.start_dt,
         a.maturity_dt,
         nvl(d.principal, 0) principal_arrears,
         nvl(d.interest, 0) interest_arrears,
         nvl(d.charge, 0) charge_arrears,
         a.disbursement_limit,
         row_number() over(partition by a.cust_id order by a.start_dt) ln_cycle,
         f.first_nm || '' || f.middle_nm || '' || f.last_nm CREDIT_OFFICER
    from loan_account a
    join loan_account_summary b
      on a.acct_id = b.acct_id
    join account c
      on c.acct_id = a.acct_id
    join product e
      on e.prod_id = c.prod_id
     and upper(e.prod_desc) not like '%VILLAGE%'
    left join tbl_ln_arreas d
      on d.acct_id = a.acct_id
    left join sysuser f
      on f.sysuser_id = a.primary_officer_id
    left join (select A.ACCT_ID, sum(p.arrear_days) as Arrear_days
                from account a,
                     loan_account d,
                     (select z.acct_id,
                             z.due_dt as due_dt,
                             max(z.svce_dt) svce_dt,
                             max(z.svce_dt) - z.due_dt as arrear_days ---Remove minus from arrear days that looped to the next month
                        from LN_ACCT_REPMNT_EVENT z, ctrl_parameter x
                       where z.rec_st in ('N', 'P', 'S', 'H')
                         and x.param_cd = 'S02'
                         and Z.EVENT_TYPE IN ('PRINCIPAL', 'INTEREST')
                      ----and z.created_by <> 'SYSTEM'
                       group by z.acct_id, z.due_dt
                       order by 1, 2) p
               where A.ACCT_ID = D.ACCT_ID
                 and P.ACCT_ID = A.ACCT_ID
               group by A.ACCT_ID) TAD
      on TAD.ACCT_ID = a.acct_id
   where b.last_disbursement_dt is not null),
tbl_cust_ln_summary as
 (select cust_id,
         sum(case
               when rec_st <> 'W' then
                ledger_bal
               else
                0
             end) ledger_bal_sum,
         sum(dr_int_accrued) dr_int_accrued_sum,
         max(last_payment_dt) last_payment_dt_cust,
         min(case
               when next_payment_dt >= trunc(sysdate) then
                next_payment_dt
             end) next_payment_dt_min,
         max(ln_cycle) curr_cycle,
         max(days_arrears) days_arrears_max,
         sum(case
               when rec_st <> 'W' then
                principal_arrears
               else
                0
             end) principal_arrears_sum,
         sum(interest_arrears) interest_arrears_sum,
         sum(charge_arrears) charge_arrears_sum
    from tbl_ln_dtls
   group by cust_id),
tbl_workpad_wout_segment as
 (select c.cust_no,
         c.cust_id,
         c.cust_nm,
         z.gender_ty GENDER,
         to_char(nvl(z.birth_dt, w.registration_dt), 'mm/dd/yyyy') DATE_OF_BIRTH,
         y.mobile CONTACT_NO_1,
         y.officephone CONTACT_NO_2,
         y.homephone CONTACT_NO_3,
         b.acct_no LAST_LOAN_ID,
         (case
           when x.cust_id is null then
            'N'
           else
            'Y'
         end) HAS_PASSIVE_PROD,
         (case
           when b.rec_st = 'W' then
            'Written-off'
           when b.rec_st = 'L' then
            'Settled'
           else
            'Active'
         end) CUST_STATUS,
         -a.ledger_bal_sum PRINCIPAL_AMT,
         a.principal_arrears_sum OVERDUE_PRN_AMT,
         -a.ledger_bal_sum + a.dr_int_accrued_sum + charge_arrears_sum PENDING_BAL_AMT,
         a.days_arrears_max DAYS_ARREARS,
         to_char(a.last_payment_dt_cust, 'mm/dd/yyyy') DATE_LST_PAYMENT,
         to_char(a.next_payment_dt_min, 'mm/dd/yyyy') DATE_NXT_PAYMENT,
         to_char(b.start_dt, 'mm/dd/yyyy') DISBURSE_DT,
         trunc(b.disbursement_limit) DISBURSE_AMT,
         to_char(nvl(b.closed_dt, b.maturity_dt), 'mm/dd/yyyy') MATURITY_DT,
         trunc(months_between(sysdate, b.start_dt)) MSD,
         (case
           when b.rec_st = 'L' then
            0
           else
            trunc(months_between(b.maturity_dt, sysdate))
         end) MTS,
         trunc(months_between(sysdate, b.closed_dt)) MSS
         --CUST_SEGMENT 
        ,
         (case
           when b.loan_cycle is null then
            a.curr_cycle
           else
            greatest(b.loan_cycle, a.curr_cycle)
         end) CUST_CYCLE
         --NEW_REPEAT_IND
        ,
         b.CREDIT_OFFICER,
         d.bu_nm          CUST_BRANCH
    from tbl_cust_ln_summary a
    join tbl_ln_dtls b
      on a.cust_id = b.cust_id
     and b.ln_cycle = a.curr_cycle
    join customer c
      on c.cust_id = a.cust_id
    join business_unit d
      on d.bu_id = c.main_branch_id
    left join person z
      on z.cust_id = a.cust_id
    left join tbl_cust_contacts y
      on y.cust_id = a.cust_id
    left join tbl_passive_svs x
      on x.cust_id = a.cust_id
    left join organisation w
      on w.cust_id = a.cust_id)

select CUST_NO,
       CUST_NM,
       GENDER,
       DATE_OF_BIRTH,
       CONTACT_NO_1,
       CONTACT_NO_2,
       CONTACT_NO_3,
       LAST_LOAN_ID,
       HAS_PASSIVE_PROD,
       CUST_STATUS,
       PRINCIPAL_AMT,
       OVERDUE_PRN_AMT,
       PENDING_BAL_AMT,
       DAYS_ARREARS,
       DATE_LST_PAYMENT,
       DATE_NXT_PAYMENT,
       DISBURSE_DT,
       DISBURSE_AMT,
       MATURITY_DT,
       MSD,
       MTS,
       MSS,
       (case
         when CUST_STATUS = 'Active' and MTS > 12 THEN
          'A12+'
         when CUST_STATUS = 'Active' and MTS = 12 THEN
          'A12'
         when CUST_STATUS = 'Active' and MTS = 11 THEN
          'A11'
         when CUST_STATUS = 'Active' and MTS = 10 THEN
          'A10'
         when CUST_STATUS = 'Active' and MTS = 9 THEN
          'A09'
         when CUST_STATUS = 'Active' and MTS = 8 THEN
          'A08'
         when CUST_STATUS = 'Active' and MTS = 7 THEN
          'A07'
         when CUST_STATUS = 'Active' and MTS = 6 THEN
          'A06'
         when CUST_STATUS = 'Active' and MTS = 5 THEN
          'A05'
         when CUST_STATUS = 'Active' and MTS = 4 THEN
          'A04'
         when CUST_STATUS = 'Active' and MTS = 3 THEN
          'A03'
         when CUST_STATUS = 'Active' and MTS = 2 THEN
          'A02'
         when CUST_STATUS = 'Active' and MTS <= 1 THEN
          'A01'
         when CUST_STATUS = 'Settled' and MSS > 24 THEN
          'OLD'
         when CUST_STATUS = 'Settled' and MSS = 24 THEN
          'S24'
         when CUST_STATUS = 'Settled' and MSS = 23 THEN
          'S23'
         when CUST_STATUS = 'Settled' and MSS = 22 THEN
          'S22'
         when CUST_STATUS = 'Settled' and MSS = 21 THEN
          'S21'
         when CUST_STATUS = 'Settled' and MSS = 20 THEN
          'S20'
         when CUST_STATUS = 'Settled' and MSS = 19 THEN
          'S19'
         when CUST_STATUS = 'Settled' and MSS = 18 THEN
          'S18'
         when CUST_STATUS = 'Settled' and MSS = 17 THEN
          'S17'
         when CUST_STATUS = 'Settled' and MSS = 16 THEN
          'S16'
         when CUST_STATUS = 'Settled' and MSS = 15 THEN
          'S15'
         when CUST_STATUS = 'Settled' and MSS = 14 THEN
          'S14'
         when CUST_STATUS = 'Settled' and MSS = 13 THEN
          'S13'
         when CUST_STATUS = 'Settled' and MSS = 12 THEN
          'S12'
         when CUST_STATUS = 'Settled' and MSS = 11 THEN
          'S11'
         when CUST_STATUS = 'Settled' and MSS = 10 THEN
          'S10'
         when CUST_STATUS = 'Settled' and MSS = 9 THEN
          'S09'
         when CUST_STATUS = 'Settled' and MSS = 8 THEN
          'S08'
         when CUST_STATUS = 'Settled' and MSS = 7 THEN
          'S07'
         when CUST_STATUS = 'Settled' and MSS = 6 THEN
          'S06'
         when CUST_STATUS = 'Settled' and MSS = 5 THEN
          'S05'
         when CUST_STATUS = 'Settled' and MSS = 4 THEN
          'S04'
         when CUST_STATUS = 'Settled' and MSS = 3 THEN
          'S03'
         when CUST_STATUS = 'Settled' and MSS = 2 THEN
          'S02'
         when CUST_STATUS = 'Settled' and MSS <= 1 THEN
          'S01'
       end) CUST_SEGMENT,
       CUST_CYCLE,
       (case
         when CUST_CYCLE = 1 and MSD <= 3 then
          'NEW'
         when CUST_STATUS = 'Settled' and MSS > 24 THEN
          'OLD'
         else
          'REPEAT'
       end) NEW_REPEAT_IND,
       CREDIT_OFFICER,
       CUST_BRANCH
  from tbl_workpad_wout_segment
 where CUST_STATUS <> 'Written-off'
