#!/bin/bash
export ORACLE_BASE=/u01/app/oracle
export ORACLE_HOME=${ORACLE_BASE}/product/19.3.0/db_home_1
export ORACLE_SID=FNGDB
export EXPORT_FOLDER=/u03/oracle/dumps


ORACLE_USER=system@fngpdb
ORACLE_PASSWORD=*******

DATE=$(date +"%Y%m%d")

rm  /u03/oracle/dumps/*.*

$ORACLE_HOME/bin/expdp $ORACLE_USER/$ORACLE_PASSWORD DUMPFILE=preEoD_expdp_FincaLive_$(date +"%d%b%G")_pm.dmp LOGFILE=PreEOD_expdp_FincaLive_$(date +"%d%b%G")_pm.log DIRECTORY=DUMPS CONTENT=ALL ENCRYPTION=ALL ENCRYPTION_PASSWORD="M4l0d!@04" SCHEMAS=FINCALIVE

