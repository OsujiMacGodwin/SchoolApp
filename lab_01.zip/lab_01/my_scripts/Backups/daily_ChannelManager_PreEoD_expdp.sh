#!/bin/bash
export ORACLE_BASE=/u01/app/oracle
export ORACLE_HOME=${ORACLE_BASE}/product/19.3.0/db_home_1
export ORACLE_SID=FNGPDB
export EXPORT_FOLDER=/u03/oracle/dumps

ORACLE_USER=system@fngpdb
ORACLE_PASSWORD=Mygh+87k-hhm4rn
DATE=$(date +"%Y%m%d")

$ORACLE_HOME/bin/expdp $ORACLE_USER/$ORACLE_PASSWORD DUMPFILE=channelManager_preEOD_expdp_$(date +"%d%b%G").dmp LOGFILE=ChannelManager_PreEOD_expdp_$(date +"%d%b%G").log DIRECTORY=DUMPS CONTENT=ALL ENCRYPTION=ALL ENCRYPTION_PASSWORD="M4l0d!@04" SCHEMAS=CHANNELMANAGER

