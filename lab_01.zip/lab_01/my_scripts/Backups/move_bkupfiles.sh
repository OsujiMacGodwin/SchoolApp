#Created by Osuji MacGodwin - DBA
echo OrbitR DB automated backupfile management on $(date +"%d-%b-%G")
#remove the PM time backup moved to vault 
rm  /u03/oracle/dumps/*_pm.* 

#mount the remote shared storage incase it is not mounted
#mount //10.69.0.211/Backup/DBBackups/Orbit-R /Backups/Orbit_Backup -o username=oracle,password=*******
#mount -t cifs //10.69.0.211/Backup/DBBackups/Orbit-R /Backups/Orbit_Backup -o username=oracle,domain=workgroup,sec=ntlm,uid=482,gid=481
#mount -t cifs -o credentials=/root/.smbfin,vers=2.0 //10.69.0.211/Backup/DBBackups/Orbit-R /Backups/Orbit_Backup

#create the directory to copy backup files to
mkdir -p /Backups/Orbit_Backup/$(date +"%G")/$(date +"%B")/$(date +"%d-%b-%G")

#copy the backup out of the OrbitR server to external storage
cp  /u03/oracle/dumps/* /Backups/Orbit_Backup/$(date +"%G")/$(date +"%B")/$(date +"%d-%b-%G")
