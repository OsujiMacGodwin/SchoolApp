CREATE ROLE c##aduser_role
/
GRANT SELECT ON sys.dba_db_links TO c##aduser_role container=all
/
GRANT SELECT ON sys.dba_data_files TO c##aduser_role container=all
/
GRANT SELECT ON sys.system_privilege_map TO c##aduser_role container=all
/
GRANT SELECT ON sys.sysauth$ TO c##aduser_role container=all
/
GRANT SELECT ON sys.col$ TO c##aduser_role container=all
/
GRANT SELECT ON sys.obj$ TO c##aduser_role container=all
/
GRANT SELECT ON sys.v_$system_parameter TO c##aduser_role container=all
/
GRANT SELECT ON sys.objauth$ TO c##aduser_role container=all
/
GRANT SELECT ON sys.table_privilege_map TO c##aduser_role container=all
/
GRANT SELECT ON sys.dba_objects TO c##aduser_role container=all
/
GRANT SELECT ON sys.dba_obj_audit_opts TO c##aduser_role container=all
/
GRANT SELECT ON sys.dba_procedures TO c##aduser_role container=all
/
GRANT SELECT ON sys.dba_profiles TO c##aduser_role container=all
/
GRANT SELECT ON sys.dba_roles TO c##aduser_role container=all
/
GRANT SELECT ON sys.dba_role_privs TO c##aduser_role container=all
/
GRANT SELECT ON sys.dba_stmt_audit_opts TO c##aduser_role container=all
/
GRANT SELECT ON sys.dba_sys_privs TO c##aduser_role container=all
/
GRANT SELECT ON sys.dba_tables TO c##aduser_role container=all 
/
GRANT SELECT ON sys.dba_indexes TO c##aduser_role container=all
/
GRANT SELECT ON sys.dba_tab_privs TO c##aduser_role container=all
/
GRANT SELECT ON sys.dba_ts_quotas TO c##aduser_role container=all
/
GRANT SELECT ON sys.dba_users TO c##aduser_role container=all
/
GRANT SELECT ON sys.dba_source TO c##aduser_role container=all
/
GRANT SELECT ON sys.dba_views TO c##aduser_role container=all
/
GRANT SELECT ON sys.product_component_version TO c##aduser_role container=all
/
GRANT SELECT ON sys.link$ TO c##aduser_role container=all
/
GRANT SELECT ON sys.user$ TO c##aduser_role container=all
/
GRANT SELECT ON sys.v_$parameter TO c##aduser_role container=all
/
GRANT SELECT ON sys.v_$log TO c##aduser_role container=all
/
GRANT SELECT ON sys.v_$pwfile_users TO c##aduser_role container=all
/
GRANT SELECT ON sys.v_$instance TO c##aduser_role container=all
/
GRANT SELECT ON sys.v_$database TO c##aduser_role container=all
/
GRANT SELECT ON sys.dba_priv_audit_opts TO c##aduser_role container=all
/
GRANT SELECT ON sys.v_$datafile TO c##aduser_role container=all
/
GRANT SELECT ON sys.v_$logfile TO c##aduser_role container=all
/
GRANT SELECT ON sys.v_$session TO c##aduser_role container=all
/
GRANT SELECT ON sys.registry$history TO c##aduser_role container=all
/
GRANT SELECT ON sys.dba_libraries TO c##aduser_role container=all
/
GRANT SELECT ON sys.dba_audit_session TO c##aduser_role container=all
/
GRANT SELECT ON sys.dba_external_tables TO c##aduser_role container=all
/
GRANT SELECT ON sys.dba_users_with_defpwd TO c##aduser_role container=all
/
GRANT SELECT ON sys.dba_tablespaces TO c##aduser_role container=all
/
GRANT SELECT ON sys.v_$encrypted_tablespaces TO c##aduser_role container=all
/
GRANT SELECT ON sys.dba_encrypted_columns TO c##aduser_role container=all
/
GRANT SELECT ON sys.dba_proxies TO c##aduser_role container=all
/
GRANT SELECT ON sys.v_$containers TO c##aduser_role container=all
/
GRANT SELECT ON sys.dba_segments to c##aduser_role container=all
/
GRANT SELECT ON sys.dba_registry to c##aduser_role container=all
/
GRANT CREATE SESSION TO c##aduser_role container=all
/
GRANT EXECUTE ON sys.dbms_flashback TO c##aduser_role container=all
/
GRANT SELECT ON sys.v_$pdbs TO c##aduser_role container=all
/
GRANT SELECT ON CDB_DB_LINKS TO c##aduser_role container=all
/
declare temp number;
begin
  SELECT count(*) into temp FROM dba_views WHERE owner='LBACSYS' AND view_name='DBA_SA_USERS';
  if (temp>0) then     
    execute immediate 'GRANT SELECT ON LBACSYS.DBA_SA_USERS TO c##aduser_role container=all';
  end if;

  SELECT count(*) into temp FROM dba_views WHERE owner='SYS' AND view_name='DBA_REGISTRY_SQLPATCH';
  if (temp > 0) then     
    execute immediate 'GRANT SELECT ON SYS.DBA_REGISTRY_SQLPATCH TO c##aduser_role container=all';
  end if;
  
  SELECT count(*) into temp FROM dba_views WHERE owner = 'SYS' AND view_name = 'AUDIT_UNIFIED_POLICIES';
  if (temp > 0) then
    execute immediate 'GRANT SELECT ON SYS.AUDIT_UNIFIED_POLICIES TO c##aduser_role container=all';
    execute immediate 'GRANT SELECT ON SYS.AUDIT_UNIFIED_ENABLED_POLICIES TO c##aduser_role container=all';
  end if;
  
  SELECT count(*) into temp FROM v$version WHERE banner LIKE '%Version 12.%';
  if (temp > 0) then     
    execute immediate 'GRANT EXECUTE ON DBMS_QOPATCH TO c##aduser_role container=all';
  end if;
  
  SELECT count(*) into temp FROM SYS.DBA_TABLES WHERE TABLE_NAME LIKE 'REPCAT%';
  if (temp > 0) then     
    execute immediate 'GRANT SELECT ON sys.dba_repcatlog TO c##aduser_role container=all';
    execute immediate 'GRANT SELECT ON sys.defpropagator TO c##aduser_role container=all';
  end if;
end;
/
CREATE USER c##aduser IDENTIFIED BY "Fgh345-wqs+tyiP"
/
GRANT c##aduser_role TO c##aduser container=all
/