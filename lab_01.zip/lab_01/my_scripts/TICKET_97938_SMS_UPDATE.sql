============= CREATE BACKUP TABLE FOR ROLL BACK ===============
create table fincalive.ACCOUNT_RELATIONSHIP_BACKUP_J2 as 
select * from fincalive.ACCOUNT_RELATIONSHIP where acct_id in 
(select acct_id from fincalive.account 
where rec_st not in ('C','L') 
and PROD_CAT_TY = 'DP' 
and Prod_id <> '24');

===========================================SMS ALART FOR ALL CUSTOMERS=============
update fincalive.ACCOUNT_RELATIONSHIP set Advice_reqd_fg = 'Y' , advice_delivery_method_cd = 'SMS' where acct_id in 
(select acct_id from fincalive.account 
where rec_st not in ('C','L') 
and PROD_CAT_TY = 'DP' 
and Prod_id <> '24');