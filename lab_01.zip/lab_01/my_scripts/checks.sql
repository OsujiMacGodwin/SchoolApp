--reconsiliation of principal
with c as (
SELECT a.currency, a.id_account,c.Value_Date
	, ISNULL(convert(decimal(18,2),a.Principal)+convert(decimal(18,2),a.Overdue_Principal),0) as Principal
	, convert(date,a.Date_Month_End) Date_Month_End
	, ISNULL(sum(convert(decimal(18,2),b.amount)),0) as amount
  FROM [201812_Loan_Account_MBal] as a with (nolock)
  join (select max(convert(date,date_month_end)) Value_Date from [201812_Loan_Account_MBal]) c on 1=1
  left join [201812_Historical_Cash_Flow] as b with (nolock)
    on a.id_account = b.id_account
	and b.Payment_Type in ('PRINCIPAL','TECHNICAL_PRINCIPAL_PAYMENT','DISBURSEMENT','TECHNICAL_DISBURSEMENT_CAPITALIZATION')
	and EOMONTH(b.payment_date, 0) = convert(date,a.date_month_end)--c.value_date
	--where a.id_account = '101012000177'
  --where convert(date,a.date_month_end) between eomonth(dateadd(m,-1,c.value_date)) and c.value_date --date of package
group by a.currency, a.Date_Month_End, a.id_account, a.Principal, a.Overdue_Principal,c.Value_Date
), 
c2 as (
select currency, Date_Month_End, id_account, Principal, amount,Value_Date
	,ISNULL(lag(Principal) over (partition by id_account order by Date_Month_End asc),0) prev_Principal
    ,abs(Principal - ISNULL(lag(Principal) over (partition by id_account order by Date_Month_End asc),0) + amount) as DIFF
  from c
)
select * 
  from c2
 where Date_Month_End > '2017-12-31' and DIFF >= 0.01 --and Date_Month_End = Value_Date 
order by Date_Month_End, id_account
;
-- checking 0 balance payments after maturity
select a.date_month_end, a.id_account,b.account_maturity_date,max(convert(date,c.payment_date))
from [201812_Loan_Account_MBal] as a with (nolock)
join [201812_Loan_Account] as b with (nolock) on a.id_account = b.id_account
join [201812_Historical_Cash_Flow] as c with (nolock)
  on a.id_account = c.id_account
  and convert(date,c.payment_date) > convert(date,b.account_maturity_date)
  and convert(decimal(18,2),c.amount) > 0
where convert(decimal(18,2),a.Principal) + convert(decimal(18,2),a.Overdue_Interest) + convert(decimal(18,2),a.Overdue_Principal) + convert(decimal(18,2),a.Interest) + convert(decimal(18,2),a.Accrued_Penalty) + convert(decimal(18,2),a.Off_Balance_Base) = 0
--and convert(date,a.Date_Month_End) >= '2017-12-01'
group by a.date_month_end, a.id_account,b.account_maturity_date
order by convert(date,a.date_month_end), a.id_account
;
--checking 0 balance maturity date in different month
SELECT a.Date_Month_End, a.id_account, b.Account_Maturity_Date
, case when (convert(date,b.Date_WO) = '1900-01-01' or convert(date,b.date_wo) > convert(date,a.Date_Month_End)) then 0 else 1 end as WrittenOff
  FROM [201812_Loan_Account_MBal] as a with (nolock)
  join [201812_Loan_Account] as b with (nolock) on a.id_account = b.id_account
  join (select max(convert(date,date_month_end)) Value_Date from [201812_Loan_Account_MBal]) c on 1=1
where convert(date,a.Date_Month_End) = c.Value_Date --value date here is the reporting date
  and convert(decimal(18,2),principal) + convert(decimal(18,2),overdue_principal) + convert(decimal(18,2),interest) + convert(decimal(18,2),Overdue_Interest) + convert(decimal(18,2),Accrued_Penalty) + convert(decimal(18,2),Off_Balance_Base) = 0
  and EOMONTH(convert(date,account_maturity_date), 0) <> c.Value_Date --value date here is the reporting date
  order by convert(date,a.date_month_end);

--checking cash flows with opposite to requirements (some exceptions may apply due to reversals)  
SELECT Payment_Type, DATE_MONTH_END, count(*)
  FROM [201812_Historical_Cash_Flow] with (nolock)
  where ((Payment_Type in ('PRINCIPAL', 'INTEREST','PENALTY','OTHER','TECHNICAL_PRINCIPAL_PAYMENT','TECHNICAL_INTEREST_PAYMENT','TECHNICAL_PENALTY_PAYMENT','TECHNICAL_OTHER_PAYMENT','DISBURSEMENT_FEE') and convert(decimal(18,2),amount) < 0)
OR (Payment_type in ('DISBURSEMENT','TECHNICAL_DISBURSEMENT_CAPITALIZATION') and convert(decimal(18,2),amount) > 0))
--and eomonth(payment_date,0) = value_date
group by Payment_Type, DATE_MONTH_END
order by Payment_Type, convert(date,DATE_MONTH_END);

--check number of records in cash flow
SELECT DATE_MONTH_END, Payment_Type, count(*), sum(convert(decimal(18,2),amount))
  FROM [201812_Historical_Cash_Flow] with (nolock)
  --where eomonth(payment_date,0) = value_date
group by Payment_Type, DATE_MONTH_END
order by Payment_Type, convert(date,DATE_MONTH_END);

-- checking min/max values
SELECT Date_Month_End
     , min(convert(decimal(18,5),Anumortized_Fee)) min_Anumortized_Fee
	 , max(convert(decimal(18,5),Anumortized_Fee)) max_Anumortized_Fee
	 , min(convert(decimal(18,5),accrued_penalty)) min_accrued_penalty
	 , max(convert(decimal(18,5),accrued_penalty)) max_accrued_penalty
	 , min(convert(decimal(18,5),Interest) + convert(decimal(18,5),Overdue_Interest)) min_Interest
	 , max(convert(decimal(18,5),Interest) + convert(decimal(18,5),Overdue_Interest)) max_Interest
  FROM [201812_Loan_Account_MBal] with (nolock)
  group by Date_Month_End
order by convert(date,Date_Month_End);

-- check effective interest rate. values greater than 1 may be suspicious
SELECT  min(convert(decimal(18,5),EIR)), max(convert(decimal(18,5),EIR))
  FROM [201812_Loan_Account] with (nolock);

--check credits where disbursement date is provided in future
SELECT Date_Month_End,a.id_account, count(*)
  FROM [201812_Loan_Account_MBal] as a with (nolock)
  inner loop join [201812_Loan_Account] as b  with (nolock) on a.id_account = b.id_account
   and convert(date,b.Loan_Disbursement_Date) > convert(date,a.date_month_end)
  join (select max(convert(date,date_month_end)) Value_Date from [201812_Loan_Account_MBal]) c on 1=1
   where a.Date_Month_End = c.Value_Date
   group by Date_Month_End,a.id_account;

--check total amounts of principal/interest/fees/penalties
SELECT Date_Month_End,b.CURRENCY, sum(principal + overdue_principal), sum(Interest + Overdue_Interest), sum(anumortized_fee), sum(accrued_penalty)
  FROM [201812_Loan_Account_MBal] as a with (nolock)
  join [201812_Loan_Account] as b with (nolock) on a.id_account = b.id_account
  join (select max(convert(date,date_month_end)) Value_Date from [201812_Loan_Account_MBal]) c on 1=1
  where Date_Month_End = c.Value_Date
  and (convert(date,b.Date_WO) = '1900-01-01' OR convert(date,b.Date_WO) > c.Value_Date)
  group by Date_Month_End,b.CURRENCY
  order by convert(date,Date_Month_End)
  
-- checking existance of 0 balance loans
select a.date_month_end, count(*)
from [201812_Loan_Account_MBal] as a with (nolock)
where convert(decimal(18,2),a.Principal) + convert(decimal(18,2),a.Overdue_Interest) + convert(decimal(18,2),a.Overdue_Principal) + convert(decimal(18,2),a.Interest) + convert(decimal(18,2),a.Accrued_Penalty) + convert(decimal(18,2),a.Off_Balance_Base) = 0
group by a.date_month_end
order by convert(date,a.date_month_end)

--negative EIR
	SELECT 'negative EIR',
		CAST(mbal.id_account AS VARCHAR(100)),
		CAST(mbal.Date_Month_End AS VARCHAR(100)),
		SUM(convert(decimal(18,2),pc.Installment_interest)) sum_Installment_interest
		,convert(decimal(18,2),mbal.interest) interest
		,convert(decimal(18,2),mbal.overdue_interest) overdue_interest
	FROM 
		[201812_Loan_Account_Mbal] mbal join
		[201812_payment_calendar] pc ON 
		mbal.id_account = pc.id_account
		AND convert(date,mbal.Date_Month_End) < convert(date,pc.Installment_Date)
	WHERE  
		convert(date,mbal.Date_Month_End) = (select max(convert(date,Date_Month_End)) from [201812_Loan_Account_Mbal])--mbal.Value_Date --Value_Date is the reporting date of package. should equal to max(date_month_end) from [201812_Loan_Account_Mbal]
	GROUP BY 
		mbal.id_account,
		mbal.Date_Month_End,
		mbal.interest,mbal.overdue_interest
	HAVING 
		SUM(convert(decimal(18,2),pc.Installment_interest)) < convert(decimal(18,2),mbal.interest);
    