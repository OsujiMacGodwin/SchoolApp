select (select T2.BU_NM
          from BUSINESS_UNIT T2, DEPOSIT_ACCOUNT D1
         where T2.BU_ID = D1.BU_ID
           and D1.ACCT_NO = T1.ACCT_NO) AS "BRANCH",
       (select P.PROD_DESC
          from Account A, product P
         where P.PROD_ID = A.PROD_ID
           and A.Acct_no = T1.ACCT_NO) as "PRODUCT",
       (SELECT SYS.FIRST_NM || ' ' || SYS.MIDDLE_NM || ' ' || SYS.LAST_NM
          FROM SYSUSER SYS, DEPOSIT_ACCOUNT A2
         WHERE A2.RSM_ID = SYS.SYSUSER_ID
           AND A2.ACCT_ID = T1.DEPOSIT_ACCT_ID) as "CREDIT OFFICER",
       (select P1.Cust_Nm
          from Account A1, Customer P1
         where P1.CUST_ID = A1.CUST_ID
           and A1.Acct_no = T1.ACCT_NO) as "CUSTOMER NAME",
       (select P1.Cust_No
          from Account A1, Customer P1
         where P1.CUST_ID = A1.CUST_ID
           and A1.Acct_no = T1.ACCT_NO) as "CUSTOMER NUMMBER",
       T1.ACCT_NO as "REPAYMENT ACCOUNT",
       (select (J.CLEARED_BAL - J.RESERVED_FUND - J.EARMARKED_FUND -
               J.UNCLEARED1_BAL) as AVA
          from deposit_account_summary J
         where J.ACCT_NO = T1.ACCT_NO) as "AVAILABLE BALANCE",
       T1.STMNT_BAL as "BOOK BALANCE",
       T1.TXN_AMT as "AMOUNT PAID",
       T1.TRAN_DESC as "TRANSACTION DESCRIPTION",
       T1.VALUE_DT as "TRANSACTION DATE"
  from (select *
          from deposit_account_history
         where DEPOSIT_ACCT_ID in
               (select distinct (PRIMARY_CUST_ID)
                  from deposit_account
                 where PROD_ID <> '28')
           and DEPOSIT_ACCT_ID in
               (select distinct (PRINCIPAL_REPAY_ACCT_ID)
                  from LOAN_ACCOUNT_PAYMENT_INFO)) T1
 where T1.DR_CR_IND = 'CR'
   and T1.EVENT_ID not in ('2082', '1007906') /*---Removed monthly Interest and disbursement */
   and T1.VALUE_DT BETWEEN '23-NOV-2018' and '25-NOV-2018'
 order by T1.ACCT_NO, T1.VALUE_DT desc
          