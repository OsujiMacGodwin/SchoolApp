Select ROW_NUMBER() OVER(ORDER BY M1.ACCT_ID) as "S/N",
       M1.ACCT_NO as "ACCOUNT_NUMBER",
       M2.CUST_NM as "CUSTOMER_NAME",
           (case when G2.PER_CONTACT_CUST_ID is null then (SELECT J.IDENT_NO
          FROM CUSTOMER_IDENTIFICATION J
         WHERE M2.CUST_ID = J.CUST_ID
           AND J.CUST_IDENT_XREF_ID = 6890)  else (SELECT J.IDENT_NO
          FROM CUSTOMER_IDENTIFICATION J
         WHERE G2.PER_CONTACT_CUST_ID = J.CUST_ID
           AND J.CUST_IDENT_XREF_ID = 6890) end )as "BVN",
       NULL as "TIN",
       'OBJECT MORTGAGE LOANS' as "FACILITY_TYPE",
       M7.INDUSTRY_SECTOR as "BUSINESS_TYPE",
       M7.INDUSTRY_CODE as "SECTOR",
       M7.SUB_INDUSTRY as "SUB_SECTOR",
       'NARIA' as "CURRENCY TYPE",
       M2.CUST_NO as "CUSTOMER_ID",
       NULL as "GROUP_ORGANIZATION",
       M4.START_DT as"DATE_GRANTED",
       M03.LAST_PAYMENT_DT as "LAST_CREDIT_DATE",
       M4.MATURITY_DT as "EXPIRY_DATE",
       M4.TERM_VALUE as "TENOR",
       ROUND((select INT_RATE from LOAN_ACCOUNTS_INTEREST_NEWTON where acct_id = N6.ACCT_ID )/12, 2) as "INTEREST_RATE",
       ROUND(M4.DISBURSEMENT_LIMIT, 2) as "SANCTION_LIMIT",
       NULL as "PREVIOUS_ LIMIT",
       NULL as "UNDRAWN_COMMITMENT",
      (case when M8.REPAY_FREQ_CD = 'W' then 'WEEKLY' when M8.REPAY_FREQ_CD = 'M' then 'MONTHLY' when M8.REPAY_FREQ_CD = 'Q' then 'QUARTERLY' else 'INVALID' end) as "REPAYMENT_FREQUENCY_1",
       NVL (F1.INT_ARREARS + F1.CHARGE + F1.PRINCIPAL_ARREARS, 0) as "CUM_REPAYMENT_AMOUNT_DUE",
          NVL ((SELECT Sum(PMT.AMT_PAID)
          FROM LN_ACCT_REPMNT_EVENT PMT
         WHERE M1.ACCT_ID = PMT.ACCT_ID
           AND PMT.EVENT_TYPE = 'PRINCIPAL') + (SELECT Sum(PMT.AMT_PAID)
          FROM LN_ACCT_REPMNT_EVENT PMT
         WHERE M1.ACCT_ID = PMT.ACCT_ID
           AND PMT.EVENT_TYPE = 'INTEREST') +  (SELECT Sum(PMT.AMT_PAID)
          FROM LN_ACCT_REPMNT_EVENT PMT
         WHERE M1.ACCT_ID = PMT.ACCT_ID
           AND PMT.EVENT_TYPE = 'CHARGE'), 0) as "CUM_REPAYMENT_AMOUNT_PAID",
       NVL(F1.INT_ARREARS,0) as "CUM_INTEREST_DUE_NOT_YET_PAID",
       NVL(F1.PRINCIPAL_ARREARS,0) as "CUM_PRINCIPAL_DUE_NOT_YET_PAID",
       'ON' as "ON_OR_OFF_BALANCE_SHEET",
       M4.DISBURSEMENT_LIMIT as "NOMINAL_VALUE",
       NULL as "CREDIT_CONVERSION_FACTOR",
       M03.CLEARED_BAL as "OUSTANDING BALANCE",
       NULL as "BANK_IFRS9_STAGING",
       (SELECT C.RISK_CLASS_PROVISION_DESC FROM  RISK_CLASS_PROVISION C WHERE C.RISK_ID =  M1.RISK_CLASS_ID AND C.RISK_CLASS_PROVISION_DESC NOT LIKE '%Restructured%' AND ROWNUM = 1 )as "BANK_CLASSIFICATION",
       NULL as "DEC. 2019 EXAMINERS CLASSIFICATION",
       NULL as "BANK_OBLIGOR_RATING",
       NULL as "PROBABILITY_OF_DEFAULT",
       M03.CLEARED_BAL as "EXPOSURE_AT_DEFAULT",
       NULL as "LOSS_GIVEN_DEFAULT",
       NULL as "EXPECTED_CREDIT_LOSS",
       (select max(b.CollATERAL_DESC)  from collateral b left join collateral_lien h on h.collateral_id = b.collateral_id group by h.cr_appl_id having h.cr_appl_id = M3.appl_id) as "DETAILS_OF_SECURITIES_OTHERS",
       NULL as "DATE_OF_LAST_EVALUATION",
      (select sum(b.lien_amt) from collateral_lien b group by b.cr_appl_id having b.cr_appl_id = M3.appl_id) as "COLLATERAL_VALUE",
       'PERFECTED' as "COLLATERAL_STATUS",
       M3.DISBURSEMENT_LIMIT as "AMOUNT TO BE RESTRUCTURED",
       M3.MATURITY_DT as "EXPIRY_DATE",
       M3.TERM_VALUE as "TENOR IN MONTHS",
       'NAIRA' as "CURRRENCY TYPE",
       NULL as "MORATORIUM (IF ANY)",
       M8.FIRST_PAY_DT as "DATE OF COMMENCEMENT OF REPAYMENT POST RESTRUCTURING",
       ROUND(M6.FIXED_RATE / 12, 2) as "INTEREST_RATE",
       (case when M8.REPAY_FREQ_CD = 'W' then 'WEEKLY' when M8.REPAY_FREQ_CD = 'M' then 'MONTHLY' when M8.REPAY_FREQ_CD = 'Q' then 'QUARTERLY' else 'INVALID' end) as "REPAYMENT_FREQUENCY_1",
       'Management Credit Committee' "APROVING AUTHORITY", ----
       'Y' as "IS APPROVAL IN PLACE? (Y/N)",
       'Y' as "REQUEST INITIATED BY CUSTOMER? (Y/N)",
       'Y' as "IMPACTED BY COVID-19? (Y/N)",
       NULL as "IF IMPACTED PROVIDE BRIEF EXPLANATION"
  FROM ACCOUNT M1
  left join (select N7.DATE_C, N8.CUST_ID, N8.ACCT_NO, N8.ACCT_ID 
               from (select max(CREATE_DT) as DATE_C, CUST_ID
                       from account
                      where PROD_ID in ('35','37')
                      group by CUST_ID) N7
               left join account N8
                 on N7.CUST_ID = N8.CUST_ID
              where N7.DATE_C = N8.CREATE_DT
                AND N8.PROD_CAT_TY = 'LN'
                and N8.REC_ST <> 'C') N6 ----OLD ACCOUNT--
    ON M1.CUST_ID = N6.CUST_ID
  left join LOAN_ACCOUNT_PAYMENT_INFO M8
    on M8.ACCT_ID = M1.ACCT_ID
  left join CUSTOMER M2
    ON M1.CUST_ID = M2.CUST_ID
  left join (select CUST_ID, PER_CONTACT_CUST_ID from ORGANISATION_PERSONAL_CONTACT  where PER_CONTACT_CUST_ID is not null) G2
    ON G2.CUST_ID = M2.CUST_ID
  left join V_CUSTOMER_INDUST_SECTOR M7
    ON M2.INDUSTRY_ID = M7.INDUSTRY_ID
  left join LOAN_ACCOUNT M3 
    ON M1.ACCT_ID = M3.ACCT_ID
  left join  LOAN_ACCOUNT_SUMMARY M03 
    ON M1.ACCT_ID = M03.ACCT_ID
  left join LOAN_ACCOUNT_INTEREST M6
    ON M1.ACCT_ID = M6.ACCT_ID
  left join LOAN_ACCOUNT M4
    ON N6.ACCT_NO = M4.ACCT_NO
  left join  (SELECT r.acct_id,
               Min(r.due_dt) MDUE_DT,
               SUM(DECODE(r.EVENT_TYPE, 'INTEREST', r.AMT_UNPAID, 0)) "INT_ARREARS",
               SUM(DECODE(r.EVENT_TYPE, 'PRINCIPAL', r.AMT_UNPAID, 0)) "PRINCIPAL_ARREARS",
               SUM(DECODE(r.EVENT_TYPE, 'CHARGE', r.AMT_UNPAID, 0)) "CHARGE"
          FROM LN_ACCT_REPMNT_EVENT r, CTRL_PARAMETER CP
         WHERE r.amt_unpaid <> 0
           AND CP.PARAM_CD = 'S02'
           AND r.DUE_DT <= TO_DATE(CP.DISPLAY_VALUE, 'dd/mm/yyyy')
           AND R.REC_ST NOT IN ('C', 'H')
         GROUP BY r.acct_id ) F1 on M1.ACCT_ID = F1.ACCT_ID
 where M1.PROD_CAT_TY = 'LN'
   and M1.PROD_ID = 77
   and M1.REC_ST not in ('C','L','W')
   --and----- M1.CREATE_DT between '01-JAN-2020' and '31-MAY-2020'
   
