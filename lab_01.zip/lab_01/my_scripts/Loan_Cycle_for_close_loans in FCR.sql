select COD_CUST_ID,
       count(*) as "CYCLE",
       (select O.CUST_NM
          from fincalive.ext_customer@orb_link O
         where O.EXT_CUST_ID = COD_CUST_ID) as "Customer Name",
       (select f.cust_no
          from fincalive.customer@orb_link     f,
               fincalive.ext_customer@orb_link x
         where f.cust_id = x.internal_cust_id
           and x.ext_cust_id = cod_cust_id) as "OrbitR Customer Number"
  from ln_acct_mast@host_link COD_CUST_ID
 where COD_ACCT_STAT in (5, 1)
 group by COD_CUST_ID
          