WITH TBL_CTRL_PARAMETER AS (
      SELECT nvl(to_date('31 Mar 2021','dd mon yyyy'),TO_DATE(PREV_DT, DT_FMT)) VALUE_DATE
        FROM (SELECT PARAM_CD, DISPLAY_VALUE
                FROM fincalive.CTRL_PARAMETER
               WHERE PARAM_CD IN ('S01', 'S19')) 
        PIVOT(MAX(DISPLAY_VALUE) FOR PARAM_CD IN('S01' PREV_DT,'S19' DT_FMT)))
,tbl_exch_rate as (
      select crncy_id,crncy_cd,exch_rate LCY_TO_USD
      from (select a.exch_rate_hist_id,a.exch_rate,a.create_dt,b.crncy_id,c.rate_sheet_nm,d.rate_ty,e.crncy_cd,a.start_effective_ts,a.end_effective_ts
                  ,row_number() over(partition by e.crncy_cd,d.rate_ty order by a.exch_rate_hist_id desc) ctr
            from fincalive.exchange_rate_history a
            join fincalive.exchange_rate b on a.exch_rate_id = b.exch_rate_id
            join fincalive.exchange_rate_template c on c.exch_rate_template_id = b.exch_rate_template_id
            join fincalive.rate_type d on d.rate_ty_id = a.rate_ty_id
            join fincalive.currency e on e.crncy_id = b.crncy_id
            join tbl_ctrl_parameter f on 1=1
            where d.rate_ty = 'Revaluation Rate'
            and e.crncy_cd = 'USD'
            and a.create_dt <= f.value_date)
      where ctr = 1
      UNION
      SELECT 841,'USD',1 FROM DUAL /*Temporary added as they don't have rates in the system yet*/
      )
,tbl_gl_balances as (
      select sum(case when a.gl_acct_cat_cd in ('IINC','NIINC') then b.ledger_bal/decode(d.crncy_id,e.crncy_id,1,e.lcy_to_usd) end) A_OP_REV_YTD
            ,sum(case when a.gl_acct_cat_cd in ('IEXP','NIEXP') then -b.ledger_bal/decode(d.crncy_id,e.crncy_id,1,e.lcy_to_usd) end) A_OP_EX_YTD
            ,sum(b.ledger_bal/decode(d.crncy_id,e.crncy_id,1,e.lcy_to_usd)) A_NET_INCOME_YTD
      from fincalive.gl_account a
      join fincalive.gl_daily_balance_history b on a.gl_acct_id = b.gl_acct_id
      join TBL_CTRL_PARAMETER c on c.VALUE_DATE = trunc(b.bal_dt)
      join fincalive.gl_account_summary d on d.gl_acct_id = a.gl_acct_id and d.gl_acct_summary_id = b.gl_acct_summary_id
      join tbl_exch_rate e on 1=1
      where gl_acct_cat_cd in ('IEXP','NIEXP','IINC','NIINC'))
,TBL_RESTRUCTURE AS (
      select b.acct_id loan_acct_id,1 restructure_cnt,min(trunc(d.row_ts)) restruct_effective_dt
            ,TRUNC(MONTHS_BETWEEN(b.MATURITY_DT,b.START_dT)) - trunc(CASE WHEN b.TERM_CD = 'D' THEN b.TERM_VALUE/30 WHEN b.TERM_CD = 'Q' THEN b.TERM_VALUE*3 WHEN b.TERM_CD = 'Y' THEN b.TERM_VALUE*12 WHEN b.TERM_CD = 'M' THEN b.TERM_VALUE END) prolong
       from fincalive.loan_account b 
       join fincalive.account c on c.acct_id = b.acct_id
       join fincalive.account$aud d on d.acct_id = b.acct_id and d.prod_id = c.prod_id
       where c.prod_id = 77
       group by b.acct_id,b.maturity_dt,b.start_dt,b.term_cd,b.term_value
       )
,TBL_LN_ACCT_DBH AS (
      SELECT SUM(A.PROVISION_BAL/decode(e.crncy_id,d.crncy_id,1,d.lcy_to_usd)) A_TOTAL_LLP_EOD,
             COUNT(A.ACCT_ID) A_N_TOTAL_LPO_EOD,
             COUNT(CASE WHEN A.DELINQUENT_DAYS >= 1 THEN -A.LEDGER_BAL END) A_N_TOTAL_LPO_DLN_EOD,
             COUNT(CASE WHEN C.LOAN_ACCT_ID IS NULL THEN -A.LEDGER_BAL END) A_N_TOTAL_LPO_NORM_ALL_EOD,
             COUNT(CASE WHEN C.LOAN_ACCT_ID IS NULL AND NVL(A.DELINQUENT_DAYS,0) = 0 THEN A.ACCT_ID END) A_N_NORM_LPO_NODLN_EOD,
             COUNT(CASE WHEN C.LOAN_ACCT_ID IS NULL AND A.DELINQUENT_DAYS BETWEEN 1 AND 7 THEN A.ACCT_ID END) A_N_NORM_LPO_ARR_1_7_EOD,
             COUNT(CASE WHEN C.LOAN_ACCT_ID IS NULL AND A.DELINQUENT_DAYS BETWEEN 8 AND 30 THEN A.ACCT_ID END) A_N_NORM_LPO_ARR_8_30_EOD,
             COUNT(CASE WHEN C.LOAN_ACCT_ID IS NULL AND A.DELINQUENT_DAYS BETWEEN 31 AND 60 THEN A.ACCT_ID END) A_N_NORM_LPO_ARR_31_60_EOD,
             COUNT(CASE WHEN C.LOAN_ACCT_ID IS NULL AND A.DELINQUENT_DAYS BETWEEN 61 AND 90 THEN A.ACCT_ID END) A_N_NORM_LPO_ARR_61_90_EOD,
             COUNT(CASE WHEN C.LOAN_ACCT_ID IS NULL AND A.DELINQUENT_DAYS BETWEEN 91 AND 120 THEN A.ACCT_ID END) A_N_NORM_LPO_ARR_91_120_EOD,
             COUNT(CASE WHEN C.LOAN_ACCT_ID IS NULL AND A.DELINQUENT_DAYS BETWEEN 121 AND 150 THEN A.ACCT_ID END) A_N_NORM_LPO_ARR_121_150_EOD,
             COUNT(CASE WHEN C.LOAN_ACCT_ID IS NULL AND A.DELINQUENT_DAYS BETWEEN 151 AND 180 THEN A.ACCT_ID END) A_N_NORM_LPO_ARR_151_180_EOD,
             COUNT(CASE WHEN C.LOAN_ACCT_ID IS NULL AND A.DELINQUENT_DAYS > 180 THEN A.ACCT_ID END) A_N_NORM_LPO_ARR_OVER180_EOD,
             ------------------------
             COUNT(CASE WHEN C.LOAN_ACCT_ID IS NOT NULL THEN -A.LEDGER_BAL END) A_N_TOTAL_LPO_REST_ALL_EOD,
             COUNT(CASE WHEN C.LOAN_ACCT_ID IS NOT NULL AND NVL(A.DELINQUENT_DAYS,0) = 0 THEN A.ACCT_ID END) A_N_REST_LPO_NODLN_EOD,
             COUNT(CASE WHEN C.LOAN_ACCT_ID IS NOT NULL AND A.DELINQUENT_DAYS BETWEEN 1 AND 7 THEN A.ACCT_ID END) A_N_REST_LPO_ARR_1_7_EOD,
             COUNT(CASE WHEN C.LOAN_ACCT_ID IS NOT NULL AND A.DELINQUENT_DAYS BETWEEN 8 AND 30 THEN A.ACCT_ID END) A_N_REST_LPO_ARR_8_30_EOD,
             COUNT(CASE WHEN C.LOAN_ACCT_ID IS NOT NULL AND A.DELINQUENT_DAYS BETWEEN 31 AND 60 THEN A.ACCT_ID END) A_N_REST_LPO_ARR_31_60_EOD,
             COUNT(CASE WHEN C.LOAN_ACCT_ID IS NOT NULL AND A.DELINQUENT_DAYS BETWEEN 61 AND 90 THEN A.ACCT_ID END) A_N_REST_LPO_ARR_61_90_EOD,
             COUNT(CASE WHEN C.LOAN_ACCT_ID IS NOT NULL AND A.DELINQUENT_DAYS BETWEEN 91 AND 120 THEN A.ACCT_ID END) A_N_REST_LPO_ARR_91_120_EOD,
             COUNT(CASE WHEN C.LOAN_ACCT_ID IS NOT NULL AND A.DELINQUENT_DAYS BETWEEN 121 AND 150 THEN A.ACCT_ID END) A_N_REST_LPO_ARR_121_150_EOD,
             COUNT(CASE WHEN C.LOAN_ACCT_ID IS NOT NULL AND A.DELINQUENT_DAYS BETWEEN 151 AND 180 THEN A.ACCT_ID END) A_N_REST_LPO_ARR_151_180_EOD,
             COUNT(CASE WHEN C.LOAN_ACCT_ID IS NOT NULL AND A.DELINQUENT_DAYS > 180 THEN A.ACCT_ID END) A_N_REST_LPO_ARR_OVER180_EOD,
             /******************/
             SUM(-A.LEDGER_BAL/decode(e.crncy_id,d.crncy_id,1,d.lcy_to_usd)) A_TOTAL_LPO_EOD,
             SUM(CASE WHEN A.DELINQUENT_DAYS >= 1 THEN -A.LEDGER_BAL/decode(e.crncy_id,d.crncy_id,1,d.lcy_to_usd) END) A_TOTAL_LPO_DLN_EOD,
             SUM(CASE WHEN C.LOAN_ACCT_ID IS NULL THEN -A.LEDGER_BAL/decode(e.crncy_id,d.crncy_id,1,d.lcy_to_usd) END) A_TOTAL_LPO_NORM_ALL_EOD,
             SUM(CASE WHEN C.LOAN_ACCT_ID IS NULL AND NVL(A.DELINQUENT_DAYS,0) = 0 THEN -A.LEDGER_BAL/decode(e.crncy_id,d.crncy_id,1,d.lcy_to_usd) END) A_NORM_LPO_NODLN_EOD,
             SUM(CASE WHEN C.LOAN_ACCT_ID IS NULL AND A.DELINQUENT_DAYS BETWEEN 1 AND 7 THEN -A.LEDGER_BAL/decode(e.crncy_id,d.crncy_id,1,d.lcy_to_usd) END) A_NORM_LPO_ARR_1_7_EOD,
             SUM(CASE WHEN C.LOAN_ACCT_ID IS NULL AND A.DELINQUENT_DAYS BETWEEN 8 AND 30 THEN -A.LEDGER_BAL/decode(e.crncy_id,d.crncy_id,1,d.lcy_to_usd) END) A_NORM_LPO_ARR_8_30_EOD,
             SUM(CASE WHEN C.LOAN_ACCT_ID IS NULL AND A.DELINQUENT_DAYS BETWEEN 31 AND 60 THEN -A.LEDGER_BAL/decode(e.crncy_id,d.crncy_id,1,d.lcy_to_usd) END) A_NORM_LPO_ARR_31_60_EOD,
             SUM(CASE WHEN C.LOAN_ACCT_ID IS NULL AND A.DELINQUENT_DAYS BETWEEN 61 AND 90 THEN -A.LEDGER_BAL/decode(e.crncy_id,d.crncy_id,1,d.lcy_to_usd) END) A_NORM_LPO_ARR_61_90_EOD,
             SUM(CASE WHEN C.LOAN_ACCT_ID IS NULL AND A.DELINQUENT_DAYS BETWEEN 91 AND 120 THEN -A.LEDGER_BAL/decode(e.crncy_id,d.crncy_id,1,d.lcy_to_usd) END) A_NORM_LPO_ARR_91_120_EOD,
             SUM(CASE WHEN C.LOAN_ACCT_ID IS NULL AND A.DELINQUENT_DAYS BETWEEN 121 AND 150 THEN -A.LEDGER_BAL/decode(e.crncy_id,d.crncy_id,1,d.lcy_to_usd) END) A_NORM_LPO_ARR_121_150_EOD,
             SUM(CASE WHEN C.LOAN_ACCT_ID IS NULL AND A.DELINQUENT_DAYS BETWEEN 151 AND 180 THEN -A.LEDGER_BAL/decode(e.crncy_id,d.crncy_id,1,d.lcy_to_usd) END) A_NORM_LPO_ARR_151_180_EOD,
             SUM(CASE WHEN C.LOAN_ACCT_ID IS NULL AND A.DELINQUENT_DAYS > 180 THEN -A.LEDGER_BAL/decode(e.crncy_id,d.crncy_id,1,d.lcy_to_usd) END) A_NORM_LPO_ARR_OVER180_EOD,
             ------------------------
             SUM(CASE WHEN C.LOAN_ACCT_ID IS NOT NULL THEN -A.LEDGER_BAL/decode(e.crncy_id,d.crncy_id,1,d.lcy_to_usd) END) A_TOTAL_LPO_REST_ALL_EOD,
             SUM(CASE WHEN C.LOAN_ACCT_ID IS NOT NULL AND NVL(A.DELINQUENT_DAYS,0) = 0 THEN -A.LEDGER_BAL/decode(e.crncy_id,d.crncy_id,1,d.lcy_to_usd) END) A_REST_LPO_NODLN_EOD,
             SUM(CASE WHEN C.LOAN_ACCT_ID IS NOT NULL AND A.DELINQUENT_DAYS BETWEEN 1 AND 7 THEN -A.LEDGER_BAL/decode(e.crncy_id,d.crncy_id,1,d.lcy_to_usd) END) A_REST_LPO_ARR_1_7_EOD,
             SUM(CASE WHEN C.LOAN_ACCT_ID IS NOT NULL AND A.DELINQUENT_DAYS BETWEEN 8 AND 30 THEN -A.LEDGER_BAL/decode(e.crncy_id,d.crncy_id,1,d.lcy_to_usd) END) A_REST_LPO_ARR_8_30_EOD,
             SUM(CASE WHEN C.LOAN_ACCT_ID IS NOT NULL AND A.DELINQUENT_DAYS BETWEEN 31 AND 60 THEN -A.LEDGER_BAL/decode(e.crncy_id,d.crncy_id,1,d.lcy_to_usd) END) A_REST_LPO_ARR_31_60_EOD,
             SUM(CASE WHEN C.LOAN_ACCT_ID IS NOT NULL AND A.DELINQUENT_DAYS BETWEEN 61 AND 90 THEN -A.LEDGER_BAL/decode(e.crncy_id,d.crncy_id,1,d.lcy_to_usd) END) A_REST_LPO_ARR_61_90_EOD,
             SUM(CASE WHEN C.LOAN_ACCT_ID IS NOT NULL AND A.DELINQUENT_DAYS BETWEEN 91 AND 120 THEN -A.LEDGER_BAL/decode(e.crncy_id,d.crncy_id,1,d.lcy_to_usd) END) A_REST_LPO_ARR_91_120_EOD,
             SUM(CASE WHEN C.LOAN_ACCT_ID IS NOT NULL AND A.DELINQUENT_DAYS BETWEEN 121 AND 150 THEN -A.LEDGER_BAL/decode(e.crncy_id,d.crncy_id,1,d.lcy_to_usd) END) A_REST_LPO_ARR_121_150_EOD,
             SUM(CASE WHEN C.LOAN_ACCT_ID IS NOT NULL AND A.DELINQUENT_DAYS BETWEEN 151 AND 180 THEN -A.LEDGER_BAL/decode(e.crncy_id,d.crncy_id,1,d.lcy_to_usd) END) A_REST_LPO_ARR_151_180_EOD,
             SUM(CASE WHEN C.LOAN_ACCT_ID IS NOT NULL AND A.DELINQUENT_DAYS > 180 THEN -A.LEDGER_BAL/decode(e.crncy_id,d.crncy_id,1,d.lcy_to_usd) END) A_REST_LPO_ARR_OVER180_EOD,
             ------------------------
             COUNT(CASE WHEN C.LOAN_ACCT_ID IS NOT NULL AND C.RESTRUCTURE_CNT = 1 THEN C.LOAN_ACCT_ID END) A_N_REST_1_LPO_EOD,
             SUM(CASE WHEN C.LOAN_ACCT_ID IS NOT NULL AND C.RESTRUCTURE_CNT = 1 THEN -A.LEDGER_BAL/decode(e.crncy_id,d.crncy_id,1,d.lcy_to_usd) END) A_REST_1_LPO_EOD,
             COUNT(CASE WHEN C.LOAN_ACCT_ID IS NOT NULL AND C.RESTRUCTURE_CNT = 2 THEN C.LOAN_ACCT_ID END) A_N_REST_2_LPO_EOD,
             SUM(CASE WHEN C.LOAN_ACCT_ID IS NOT NULL AND C.RESTRUCTURE_CNT = 2 THEN -A.LEDGER_BAL/decode(e.crncy_id,d.crncy_id,1,d.lcy_to_usd) END) A_REST_2_LPO_EOD,
             COUNT(CASE WHEN C.LOAN_ACCT_ID IS NOT NULL AND C.RESTRUCTURE_CNT = 3 THEN C.LOAN_ACCT_ID END) A_N_REST_3_LPO_EOD,
             SUM(CASE WHEN C.LOAN_ACCT_ID IS NOT NULL AND C.RESTRUCTURE_CNT = 3 THEN -A.LEDGER_BAL/decode(e.crncy_id,d.crncy_id,1,d.lcy_to_usd) END) A_REST_3_LPO_EOD,
             COUNT(CASE WHEN C.LOAN_ACCT_ID IS NOT NULL AND C.RESTRUCTURE_CNT >= 4 THEN C.LOAN_ACCT_ID END) A_N_REST_OVER4_LPO_EOD,
             SUM(CASE WHEN C.LOAN_ACCT_ID IS NOT NULL AND C.RESTRUCTURE_CNT >= 4 THEN -A.LEDGER_BAL/decode(e.crncy_id,d.crncy_id,1,d.lcy_to_usd) END) A_REST_OVER4_LPO_EOD,
             ------------------------
             COUNT(CASE WHEN C.LOAN_ACCT_ID IS NOT NULL AND C.PROLONG < 3 THEN C.LOAN_ACCT_ID END) A_N_REST_LPO_PRLN_0_3_EOD,
             SUM(CASE WHEN C.LOAN_ACCT_ID IS NOT NULL AND C.PROLONG < 3 THEN -A.LEDGER_BAL/decode(e.crncy_id,d.crncy_id,1,d.lcy_to_usd) END) A_REST_LPO_PRLN_0_3_EOD,
             COUNT(CASE WHEN C.LOAN_ACCT_ID IS NOT NULL AND C.PROLONG between 3 and 6 THEN C.LOAN_ACCT_ID END) A_N_REST_LPO_PRLN_3_6_EOD,
             SUM(CASE WHEN C.LOAN_ACCT_ID IS NOT NULL AND C.PROLONG between 3 and 6 THEN -A.LEDGER_BAL/decode(e.crncy_id,d.crncy_id,1,d.lcy_to_usd) END) A_REST_LPO_PRLN_3_6_EOD,
             COUNT(CASE WHEN C.LOAN_ACCT_ID IS NOT NULL AND C.PROLONG between 7 and 12 THEN C.LOAN_ACCT_ID END) A_N_REST_LPO_PRLN_7_12_EOD,
             SUM(CASE WHEN C.LOAN_ACCT_ID IS NOT NULL AND C.PROLONG between 7 and 12 THEN -A.LEDGER_BAL/decode(e.crncy_id,d.crncy_id,1,d.lcy_to_usd) END) A_REST_LPO_PRLN_7_12_EOD,
             COUNT(CASE WHEN C.LOAN_ACCT_ID IS NOT NULL AND C.PROLONG >= 12 THEN C.LOAN_ACCT_ID END) A_N_REST_LPO_PRLN_OVER12_EOD,
             SUM(CASE WHEN C.LOAN_ACCT_ID IS NOT NULL AND C.PROLONG >= 12 THEN -A.LEDGER_BAL/decode(e.crncy_id,d.crncy_id,1,d.lcy_to_usd) END) A_REST_LPO_PRLN_OVER12_EOD
      FROM fincalive.LN_ACCT_DAILY_BAL_HIST A
      JOIN TBL_CTRL_PARAMETER B ON A.PROCESS_DT = B.VALUE_DATE
      join tbl_exch_Rate d on 1=1
      join fincalive.account e on e.acct_id = a.acct_id
      LEFT JOIN TBL_RESTRUCTURE C ON C.LOAN_ACCT_ID = A.ACCT_ID AND A.PROCESS_DT >= C.restruct_effective_dt
      WHERE (A.LEDGER_BAL < 0 OR A.DR_INT_ACCRUED <> 0)
      AND A.ACCT_REC_ST NOT IN ('W'))
,tbl_overdrafts as (
      select count(a.acct_id) A_N_TOTAL_OD_EOD
            ,count(case when (case when a.process_dt > nvl(greatest(c.last_od_dt,b.expiry_dt),c.delinquent_dt) then a.process_dt-nvl(greatest(c.last_od_dt,b.expiry_dt),c.delinquent_dt) else 0 end) = 0 then a.acct_id end) A_N_OD_NODLN_EOD
            ,count(case when (case when a.process_dt > nvl(greatest(c.last_od_dt,b.expiry_dt),c.delinquent_dt) then a.process_dt-nvl(greatest(c.last_od_dt,b.expiry_dt),c.delinquent_dt) else 0 end) between 1 and 7 then a.acct_id end) A_N_OD_ARR_1_7_EOD
            ,count(case when (case when a.process_dt > nvl(greatest(c.last_od_dt,b.expiry_dt),c.delinquent_dt) then a.process_dt-nvl(greatest(c.last_od_dt,b.expiry_dt),c.delinquent_dt) else 0 end) between 8 and 30 then a.acct_id end) A_N_OD_ARR_8_30_EOD
            ,count(case when (case when a.process_dt > nvl(greatest(c.last_od_dt,b.expiry_dt),c.delinquent_dt) then a.process_dt-nvl(greatest(c.last_od_dt,b.expiry_dt),c.delinquent_dt) else 0 end) between 31 and 60 then a.acct_id end) A_N_OD_ARR_31_60_EOD
            ,count(case when (case when a.process_dt > nvl(greatest(c.last_od_dt,b.expiry_dt),c.delinquent_dt) then a.process_dt-nvl(greatest(c.last_od_dt,b.expiry_dt),c.delinquent_dt) else 0 end) between 61 and 90 then a.acct_id end) A_N_OD_ARR_61_90_EOD
            ,count(case when (case when a.process_dt > nvl(greatest(c.last_od_dt,b.expiry_dt),c.delinquent_dt) then a.process_dt-nvl(greatest(c.last_od_dt,b.expiry_dt),c.delinquent_dt) else 0 end) between 91 and 120 then a.acct_id end) A_N_OD_ARR_91_120_EOD
            ,count(case when (case when a.process_dt > nvl(greatest(c.last_od_dt,b.expiry_dt),c.delinquent_dt) then a.process_dt-nvl(greatest(c.last_od_dt,b.expiry_dt),c.delinquent_dt) else 0 end) between 121 and 150 then a.acct_id end) A_N_OD_ARR_121_150_EOD
            ,count(case when (case when a.process_dt > nvl(greatest(c.last_od_dt,b.expiry_dt),c.delinquent_dt) then a.process_dt-nvl(greatest(c.last_od_dt,b.expiry_dt),c.delinquent_dt) else 0 end) between 151 and 180 then a.acct_id end) A_N_OD_ARR_151_180_EOD
            ,count(case when (case when a.process_dt > nvl(greatest(c.last_od_dt,b.expiry_dt),c.delinquent_dt) then a.process_dt-nvl(greatest(c.last_od_dt,b.expiry_dt),c.delinquent_dt) else 0 end) > 180 then a.acct_id end) A_N_OD_ARR_OVER180_EOD
            ,sum(-a.ledger_bal/decode(e.crncy_id,f.crncy_id,1,f.lcy_to_usd)) A_TOTAL_OD_EOD
            ,sum(case when (case when a.process_dt > nvl(greatest(c.last_od_dt,b.expiry_dt),c.delinquent_dt) then a.process_dt-nvl(greatest(c.last_od_dt,b.expiry_dt),c.delinquent_dt) else 0 end) = 0 then -a.ledger_bal/decode(e.crncy_id,f.crncy_id,1,f.lcy_to_usd) end) A_OD_NODLN_EOD
            ,sum(case when (case when a.process_dt > nvl(greatest(c.last_od_dt,b.expiry_dt),c.delinquent_dt) then a.process_dt-nvl(greatest(c.last_od_dt,b.expiry_dt),c.delinquent_dt) else 0 end) between 1 and 7 then -a.ledger_bal/decode(e.crncy_id,f.crncy_id,1,f.lcy_to_usd) end) A_OD_ARR_1_7_EOD
            ,sum(case when (case when a.process_dt > nvl(greatest(c.last_od_dt,b.expiry_dt),c.delinquent_dt) then a.process_dt-nvl(greatest(c.last_od_dt,b.expiry_dt),c.delinquent_dt) else 0 end) between 8 and 30 then -a.ledger_bal/decode(e.crncy_id,f.crncy_id,1,f.lcy_to_usd) end) A_OD_ARR_8_30_EOD
            ,sum(case when (case when a.process_dt > nvl(greatest(c.last_od_dt,b.expiry_dt),c.delinquent_dt) then a.process_dt-nvl(greatest(c.last_od_dt,b.expiry_dt),c.delinquent_dt) else 0 end) between 31 and 60 then -a.ledger_bal/decode(e.crncy_id,f.crncy_id,1,f.lcy_to_usd) end) A_OD_ARR_31_60_EOD
            ,sum(case when (case when a.process_dt > nvl(greatest(c.last_od_dt,b.expiry_dt),c.delinquent_dt) then a.process_dt-nvl(greatest(c.last_od_dt,b.expiry_dt),c.delinquent_dt) else 0 end) between 61 and 90 then -a.ledger_bal/decode(e.crncy_id,f.crncy_id,1,f.lcy_to_usd) end) A_OD_ARR_61_90_EOD
            ,sum(case when (case when a.process_dt > nvl(greatest(c.last_od_dt,b.expiry_dt),c.delinquent_dt) then a.process_dt-nvl(greatest(c.last_od_dt,b.expiry_dt),c.delinquent_dt) else 0 end) between 91 and 120 then -a.ledger_bal/decode(e.crncy_id,f.crncy_id,1,f.lcy_to_usd) end) A_OD_ARR_91_120_EOD
            ,sum(case when (case when a.process_dt > nvl(greatest(c.last_od_dt,b.expiry_dt),c.delinquent_dt) then a.process_dt-nvl(greatest(c.last_od_dt,b.expiry_dt),c.delinquent_dt) else 0 end) between 121 and 150 then -a.ledger_bal/decode(e.crncy_id,f.crncy_id,1,f.lcy_to_usd) end) A_OD_ARR_121_150_EOD
            ,sum(case when (case when a.process_dt > nvl(greatest(c.last_od_dt,b.expiry_dt),c.delinquent_dt) then a.process_dt-nvl(greatest(c.last_od_dt,b.expiry_dt),c.delinquent_dt) else 0 end) between 151 and 180 then -a.ledger_bal/decode(e.crncy_id,f.crncy_id,1,f.lcy_to_usd) end) A_OD_ARR_151_180_EOD
            ,sum(case when (case when a.process_dt > nvl(greatest(c.last_od_dt,b.expiry_dt),c.delinquent_dt) then a.process_dt-nvl(greatest(c.last_od_dt,b.expiry_dt),c.delinquent_dt) else 0 end) > 180 then -a.ledger_bal/decode(e.crncy_id,f.crncy_id,1,f.lcy_to_usd) end) A_OD_ARR_OVER180_EOD
      from fincalive.dp_acct_daily_bal_hist a
      join fincalive.deposit_account_summary c on c.deposit_acct_id = a.acct_id
      join fincalive.deposit_account e on e.acct_id = a.acct_id 
      join tbl_exch_rate f on 1=1
      JOIN TBL_CTRL_PARAMETER d ON A.PROCESS_DT = d.VALUE_DATE
      left join (select deposit_acct_id,max(expiry_dt) expiry_dt
                from fincalive.credit_appl_od_info 
                group by deposit_acct_id
                ) b on a.acct_id = b.deposit_acct_id
      where a.ledger_bal < 0)
,TBL_SAVINGS AS (
      SELECT COUNT(CUST_ID) A_N_TOTAL_ALL_CUST_EOD
            ,SUM(SD_LEDGER_BAL) A_TOTAL_SDP_EOD
            ,SUM(CASE WHEN TOP_N <= 10 THEN SD_LEDGER_BAL END) A_TOP10_SDP_EOD
            ,SUM(SD_CNT_ACCT) A_N_TOTAL_SDP_EOD
      FROM (SELECT C.*,ROW_NUMBER() OVER(ORDER BY SD_LEDGER_BAL DESC NULLS LAST) TOP_N
      FROM (SELECT *
            FROM (SELECT A.CUST_ID,B.CAT,SUM(B.LEDGER_BAL) LEDGER_BAL,COUNT(B.ACCT_ID) CNT_ACCT
                        FROM fincalive.ACCOUNT A
                        JOIN (SELECT A.ACCT_ID,A.LEDGER_BAL/decode(C.crncy_id,d.crncy_id,1,d.lcy_to_usd) LEDGER_BAL,'SD' CAT
                              FROM fincalive.DP_ACCT_DAILY_BAL_HIST A
                              JOIN TBL_CTRL_PARAMETER B ON B.VALUE_DATE = A.PROCESS_DT
                              JOIN fincalive.ACCOUNT C ON C.ACCT_ID = A.ACCT_ID
                              join tbl_exch_Rate d on 1=1
                              WHERE ACCT_REC_ST NOT IN ('L','C','W') AND LEDGER_BAL >= 0
                              UNION ALL
                              SELECT A.ACCT_ID,-A.LEDGER_BAL/decode(C.crncy_id,d.crncy_id,1,d.lcy_to_usd) LEDGER_BAL,'OD' CAT
                              FROM fincalive.DP_ACCT_DAILY_BAL_HIST A
                              JOIN TBL_CTRL_PARAMETER B ON B.VALUE_DATE = A.PROCESS_DT
                              JOIN fincalive.ACCOUNT C ON C.ACCT_ID = A.ACCT_ID
                              join tbl_exch_Rate d on 1=1
                              WHERE ACCT_REC_ST NOT IN ('L','C','W') AND LEDGER_BAL < 0
                              UNION ALL
                              SELECT A.ACCT_ID,A.LEDGER_BAL/decode(C.crncy_id,d.crncy_id,1,d.lcy_to_usd) LEDGER_BAL,'SD' CAT
                              FROM fincalive.TD_ACCT_DAILY_BAL_HIST A
                              JOIN TBL_CTRL_PARAMETER B ON B.VALUE_DATE = A.PROCESS_DT
                              JOIN fincalive.ACCOUNT C ON C.ACCT_ID = A.ACCT_ID
                              join tbl_exch_Rate d on 1=1
                              WHERE ACCT_REC_ST NOT IN ('L','C','W') AND LEDGER_BAL >= 0
                              UNION ALL
                              SELECT A.ACCT_ID,-A.LEDGER_BAL/decode(C.crncy_id,d.crncy_id,1,d.lcy_to_usd) LEDGER_BAL,'LN' CAT
                              FROM fincalive.LN_ACCT_DAILY_BAL_HIST A
                              JOIN TBL_CTRL_PARAMETER B ON B.VALUE_DATE = A.PROCESS_DT
                              JOIN fincalive.ACCOUNT C ON C.ACCT_ID = A.ACCT_ID
                              join tbl_exch_Rate d on 1=1
                              WHERE ACCT_REC_ST NOT IN ('L','C','W') AND (LEDGER_BAL < 0 OR DR_INT_ACCRUED <> 0)
                              )B ON A.ACCT_ID = B.ACCT_ID
                        GROUP BY A.CUST_ID,B.CAT)
            PIVOT(SUM(LEDGER_BAL) LEDGER_BAL,SUM(CNT_ACCT) CNT_ACCT FOR CAT IN ('SD' SD,'LN' LN,'OD' OD)))C))      
,tbl_ln_collections as (
      select sum(b.principal_ytd) A_TOTAL_PRI_COL_YTD,
             sum(b.principal_ytd_rec) A_TOTAL_PRI_RECOVERY_YTD,
             sum(case when a.delinquent_dt is null then principal_mtd end) A_NODLN_LPO_COL_PRI_MTD,
             sum(case when a.delinquent_dt is null then charges_mtd end) A_NODLN_LPO_COL_CHG_MTD,
             sum(case when a.delinquent_dt is null and c.loan_acct_id is null then principal_mtd end) A_NODLN_NORM_LPO_COL_PRI_MTD,
             sum(case when a.delinquent_dt is null and c.loan_acct_id is null then charges_mtd end) A_NODLN_NORM_LPO_COL_CHG_MTD,
             sum(case when a.delinquent_dt is null and c.loan_acct_id is not null then principal_mtd end) A_NODLN_REST_LPO_COL_PRI_MTD,
             sum(case when a.delinquent_dt is null and c.loan_acct_id is not null then charges_mtd end) A_NODLN_REST_LPO_COL_CHG_MTD,
             sum(case when a.delinquent_dt is not null then principal_mtd end) A_DLN_LPO_COL_PRI_MTD,
             sum(case when a.delinquent_dt is not null then charges_mtd end) A_DLN_LPO_COL_CHG_MTD,
             sum(case when a.delinquent_dt is not null and c.loan_acct_id is null then principal_mtd end) A_DLN_NORM_LPO_COL_PRI_MTD,
             sum(case when a.delinquent_dt is not null and c.loan_acct_id is null then charges_mtd end) A_DLN_NORM_LPO_COL_CHG_MTD,
             sum(case when a.delinquent_dt is not null and c.loan_acct_id is not null then principal_mtd end) A_DLN_REST_LPO_COL_PRI_MTD,
             sum(case when a.delinquent_dt is not null and c.loan_acct_id is not null then charges_mtd end) A_DLN_REST_LPO_COL_CHG_MTD,
             sum(b.principal_mtd_rec) A_TOTAL_RECOVERY_PRI_MTD,
             sum(b.charges_mtd_rec) A_TOTAL_RECOVERY_CHG_MTD
      from fincalive.loan_account_summary a
      join (select *
            from (select b.acct_no,b.ln_acct_id
                        ,(case when b.event_id in (1009322,3035) then /*'DISBURSEMENT_FEE'*/'CHARGES'
                               when b.event_id in (3039,1009341,1010294) then 'PRINCIPAL'
                               when b.event_id in (3042,1008659,1009340,1010295,3593) then /*'INTEREST'*/'CHARGES'
                               when b.event_id in (3043,1010297) then /*'PENALTY'*/'CHARGES'
                         end) cmp_txn_desc
                        ,(case when to_char(b.create_dt,'yyyymm') = to_char(a.value_date,'yyyymm') then b.txn_amt/decode(b.txn_crncy_id,c.crncy_id,1,c.lcy_to_usd) end) txn_amt_mtd
                        ,(case when to_char(b.create_dt,'yyyy') = to_char(a.value_date,'yyyy') then b.txn_amt/decode(b.txn_crncy_id,c.crncy_id,1,c.lcy_to_usd) end) txn_amt_ytd
                        ,(case when to_char(b.create_dt,'yyyymm') = to_char(a.value_date,'yyyymm') and b.create_dt > d.writeoff_dt then b.txn_amt/decode(b.txn_crncy_id,c.crncy_id,1,c.lcy_to_usd)  end) txn_amt_mtd_rec
                        ,(case when to_char(b.create_dt,'yyyy') = to_char(a.value_date,'yyyy') and b.create_dt > d.writeoff_dt then b.txn_amt/decode(b.txn_crncy_id,c.crncy_id,1,c.lcy_to_usd) end) txn_amt_ytd_rec
                        ,b.txn_crncy_id
                  from fincalive.loan_account_history b 
                  join tbl_ctrl_parameter a on 1=1
                  join tbl_exch_rate c on 1=1
                  left join (select nvl(a.acct_id,b.acct_id) acct_id
                                      ,nvl(a.writeoff_dt,b.status_effective_dt) writeoff_dt
                              from (select acct_id,min(review_dt) writeoff_dt
                                    from fincalive.account_review 
                                    where new_acct_st = 'W'
                                    group by acct_id)a
                              full join (select acct_id,nvl(status_effective_dt,create_dt) status_effective_dt 
                                        from fincalive.account where prod_cat_ty = 'LN' and rec_st = 'W'
                                        )b on a.acct_id = b.acct_id
                              )d on d.acct_id = b.ln_acct_id
                  where to_char(b.create_dt,'yyyy') = to_char(a.value_date,'yyyy')
                  and b.create_dt <= a.value_date
                  )a
            pivot(sum(txn_amt_mtd) mtd,sum(txn_amt_ytd) ytd,sum(txn_amt_mtd_rec) mtd_rec,sum(txn_amt_ytd_rec) ytd_rec for cmp_txn_desc in ('CHARGES' CHARGES,'PRINCIPAL' PRINCIPAL))
            )b on a.acct_id = b.ln_acct_id
      left join tbl_restructure c on c.loan_acct_id = a.acct_id)
,tbl_disbursements as (
      select sum(case when to_char(a.start_dt,'yyyy')=to_char(value_date,'yyyy') then a.disbursement_limit end) A_TOTAL_GLP_DISB_EOD
            ,count(case when to_char(a.start_dt,'yyyymm')=to_char(value_date,'yyyymm') and (ln_cycle = 1 or nvl(trunc(months_between(value_date,prev_closed_dt)),0) >= 24) then a.disbursement_limit end) A_N_LPO_DISB_NEW_MTD
            ,sum(case when to_char(a.start_dt,'yyyymm')=to_char(value_date,'yyyymm') and (ln_cycle = 1 or nvl(trunc(months_between(value_date,prev_closed_dt)),0) >= 24) then a.disbursement_limit end) A_LPO_DISB_NEW_MTD
            ,count(case when to_char(a.start_dt,'yyyymm')=to_char(value_date,'yyyymm') and ln_cycle > 1 and nvl(trunc(months_between(value_date,prev_closed_dt)),0) < 24 then a.disbursement_limit end) A_N_LPO_DISB_REP_MTD
            ,sum(case when to_char(a.start_dt,'yyyymm')=to_char(value_date,'yyyymm') and ln_cycle > 1 and nvl(trunc(months_between(value_date,prev_closed_dt)),0) < 24 then a.disbursement_limit end) A_LPO_DISB_REP_MTD
      from (select b.cust_id,a.acct_no,a.last_disbursement_dt,b.disbursement_limit/decode(b.crncy_id,d.crncy_id,1,d.lcy_to_usd) disbursement_limit,c.value_date
            ,b.start_dt,b.closed_dt,a.last_payment_dt,a.ledger_bal,a.dr_int_accrued
            ,row_number() over(partition by b.cust_id order by a.acct_id) ln_cycle
            ,lag(case when a.ledger_bal = 0 and a.dr_int_accrued = 0 then a.last_payment_dt end) over(partition by b.cust_id order by a.acct_id) prev_closed_dt
            from fincalive.loan_account_summary a
            join fincalive.loan_account b on a.acct_id = b.acct_id
            join tbl_ctrl_parameter c on 1=1
            join tbl_exch_rate d on 1=1
            where last_disbursement_dt is not null )a
       where to_char(a.start_dt,'yyyy')=to_char(value_date,'yyyy') 
       and a.start_dt <= value_date)
,tbl_writeoffs as (
      select count(a.acct_id) A_N_TOTAL_WO_LPO_MTD,
             sum(-b.ledger_bal/decode(d.crncy_id,c.crncy_id,1,c.lcy_to_usd)) A_TOTAL_WO_PRI_MTD,
             sum((b.dr_int_accrued + b.fee_arrear + b.late_fee_arrear)/decode(d.crncy_id,c.crncy_id,1,c.lcy_to_usd)) A_TOTAL_WO_CHG_MTD,
             count(a.acct_id) A_N_TOTAL_WO_LPO_2017TD,
             sum(-b.ledger_bal/decode(d.crncy_id,c.crncy_id,1,c.lcy_to_usd)) A_TOTAL_WO_PRI_2017TD,
             sum((b.dr_int_accrued + b.fee_arrear + b.late_fee_arrear)/decode(d.crncy_id,c.crncy_id,1,c.lcy_to_usd)) A_TOTAL_WO_CHG_2017TD
      from (select nvl(a.acct_id,b.acct_id) acct_id
                  ,nvl(a.writeoff_dt,b.status_effective_dt) writeoff_dt
            from (select acct_id,min(review_dt) writeoff_dt
                  from fincalive.account_review 
                  where new_acct_st = 'W'
                  group by acct_id)a
            full join (select acct_id,nvl(status_effective_dt,create_dt) status_effective_dt 
                      from fincalive.account where prod_cat_ty = 'LN' and rec_st = 'W'
                      )b on a.acct_id = b.acct_id
            )a
      join fincalive.ln_acct_daily_bal_hist b on a.acct_id = b.acct_id and b.process_dt = a.writeoff_dt and b.acct_rec_st = 'W'
      join tbl_ctrl_parameter e on 1=1
      join tbl_exch_rate c on 1=1
      join fincalive.account d on d.acct_id = b.acct_id
      where a.writeoff_dt between to_date('1 Jan 2017','dd mon yyyy') and e.value_date )
----------------------
select a.*
      ,b.LCY_TO_USD
      ,c.*
      ,d.A_TOTAL_LLP_EOD
      ,E.A_TOTAL_SDP_EOD,E.A_TOP10_SDP_EOD
      ,g.A_TOTAL_GLP_DISB_EOD
      ,(D.A_TOTAL_LPO_EOD + NVL(Z.A_TOTAL_OD_EOD,0)) A_TOTAL_GLP_EOD
      ,(D.A_TOTAL_LPO_DLN_EOD + NVL(Z.A_TOTAL_OD_EOD-Z.A_OD_NODLN_EOD,0)) A_TOTAL_GLP_DLN_EOD
      ,f.A_TOTAL_PRI_COL_YTD,f.A_TOTAL_PRI_RECOVERY_YTD
      ,E.A_N_TOTAL_ALL_CUST_EOD,E.A_N_TOTAL_SDP_EOD
      ------------------
      ,d.A_N_TOTAL_LPO_EOD,d.A_N_TOTAL_LPO_DLN_EOD,d.A_N_TOTAL_LPO_NORM_ALL_EOD,d.A_N_NORM_LPO_NODLN_EOD,d.A_N_NORM_LPO_ARR_1_7_EOD
      ,d.A_N_NORM_LPO_ARR_8_30_EOD,d.A_N_NORM_LPO_ARR_31_60_EOD,d.A_N_NORM_LPO_ARR_61_90_EOD,d.A_N_NORM_LPO_ARR_91_120_EOD
      ,d.A_N_NORM_LPO_ARR_121_150_EOD,d.A_N_NORM_LPO_ARR_151_180_EOD,d.A_N_NORM_LPO_ARR_OVER180_EOD,d.A_N_TOTAL_LPO_REST_ALL_EOD
      ,d.A_N_REST_LPO_NODLN_EOD,d.A_N_REST_LPO_ARR_1_7_EOD,d.A_N_REST_LPO_ARR_8_30_EOD,d.A_N_REST_LPO_ARR_31_60_EOD,d.A_N_REST_LPO_ARR_61_90_EOD
      ,d.A_N_REST_LPO_ARR_91_120_EOD,d.A_N_REST_LPO_ARR_121_150_EOD,d.A_N_REST_LPO_ARR_151_180_EOD,d.A_N_REST_LPO_ARR_OVER180_EOD,d.A_TOTAL_LPO_EOD
      ,d.A_TOTAL_LPO_DLN_EOD,d.A_TOTAL_LPO_NORM_ALL_EOD,d.A_NORM_LPO_NODLN_EOD,d.A_NORM_LPO_ARR_1_7_EOD,d.A_NORM_LPO_ARR_8_30_EOD,d.A_NORM_LPO_ARR_31_60_EOD
      ,d.A_NORM_LPO_ARR_61_90_EOD,d.A_NORM_LPO_ARR_91_120_EOD,d.A_NORM_LPO_ARR_121_150_EOD,d.A_NORM_LPO_ARR_151_180_EOD,d.A_NORM_LPO_ARR_OVER180_EOD
      ,d.A_TOTAL_LPO_REST_ALL_EOD,d.A_REST_LPO_NODLN_EOD,d.A_REST_LPO_ARR_1_7_EOD,d.A_REST_LPO_ARR_8_30_EOD,d.A_REST_LPO_ARR_31_60_EOD,d.A_REST_LPO_ARR_61_90_EOD
      ,d.A_REST_LPO_ARR_91_120_EOD,d.A_REST_LPO_ARR_121_150_EOD,d.A_REST_LPO_ARR_151_180_EOD,d.A_REST_LPO_ARR_OVER180_EOD
      ----------------
      ,f.A_NODLN_LPO_COL_PRI_MTD,f.A_NODLN_LPO_COL_CHG_MTD,f.A_NODLN_NORM_LPO_COL_PRI_MTD,f.A_NODLN_NORM_LPO_COL_CHG_MTD
      ,f.A_NODLN_REST_LPO_COL_PRI_MTD,f.A_NODLN_REST_LPO_COL_CHG_MTD,f.A_DLN_LPO_COL_PRI_MTD,f.A_DLN_LPO_COL_CHG_MTD
      ,f.A_DLN_NORM_LPO_COL_PRI_MTD,f.A_DLN_NORM_LPO_COL_CHG_MTD,f.A_DLN_REST_LPO_COL_PRI_MTD,f.A_DLN_REST_LPO_COL_CHG_MTD
      -----------------
      ,y.A_N_TOTAL_WO_LPO_MTD,y.A_TOTAL_WO_PRI_MTD,y.A_TOTAL_WO_CHG_MTD
      ,f.A_TOTAL_RECOVERY_PRI_MTD,f.A_TOTAL_RECOVERY_CHG_MTD
      ,d.A_N_REST_LPO_PRLN_0_3_EOD,d.A_REST_LPO_PRLN_0_3_EOD,d.A_N_REST_LPO_PRLN_3_6_EOD,d.A_REST_LPO_PRLN_3_6_EOD,d.A_N_REST_LPO_PRLN_7_12_EOD
      ,d.A_REST_LPO_PRLN_7_12_EOD,d.A_N_REST_LPO_PRLN_OVER12_EOD,d.A_REST_LPO_PRLN_OVER12_EOD,d.A_N_REST_1_LPO_EOD,d.A_REST_1_LPO_EOD,d.A_N_REST_2_LPO_EOD
      ,d.A_REST_2_LPO_EOD,d.A_N_REST_3_LPO_EOD,d.A_REST_3_LPO_EOD,d.A_N_REST_OVER4_LPO_EOD,d.A_REST_OVER4_LPO_EOD
      ----------------------
      ,g.A_N_LPO_DISB_NEW_MTD,g.A_LPO_DISB_NEW_MTD,g.A_N_LPO_DISB_REP_MTD,g.A_LPO_DISB_REP_MTD
      ,z.*
      ,y.A_N_TOTAL_WO_LPO_2017TD,y.A_TOTAL_WO_PRI_2017TD,y.A_TOTAL_WO_CHG_2017TD
from tbl_ctrl_parameter a
join tbl_exch_rate b on 1=1
join tbl_gl_balances c on 1=1
join TBL_LN_ACCT_DBH d on 1=1
JOIN TBL_SAVINGS E ON 1=1
join tbl_ln_collections f on 1=1
join tbl_disbursements g on 1=1
left join tbl_overdrafts z on 1=1
left join tbl_writeoffs y on 1=1
;
------------
