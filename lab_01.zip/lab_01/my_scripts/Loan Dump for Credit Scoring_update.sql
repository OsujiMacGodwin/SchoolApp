SELECT d.su_nm
       ,c.bu_nm
       ,c.bu_no
       ---,f.template_nm
       ,e.prod_cd
       ,e.prod_desc
       ,(select XR.ACCT_NO from ext_account xr where Xr.INT_ACCT_ID = b.acct_id ) as old_acct_no
       ,b.acct_no
       ,z."National_IDCard"
       --,g.cust_cat
       --,h.ref_desc
       ,nvl(y.birth_dt,x.registration_dt) birth_or_reg_dt
       ,g.cust_no
       ,(select XS.EXT_CUST_ID from ext_account xs where xs.INT_ACCT_ID = b.acct_id ) as old_cust_no
       ,g.cust_nm
       ,i.cust_ty
       ,i.cust_ty_desc
       ,w.industry_cd
       ,trim(REGEXP_REPLACE(w.sub_industry, '[[:space:]]*', '' )) as sub_industry
       ,trim(REGEXP_REPLACE(l.rsn_desc, '[[:space:]]*', '' )) as rsn_desc
       ,y.gender_ty
       ,floor(months_between(a.process_dt,nvl(y.birth_dt,x.registration_dt))/12) AGE
       ,m.calc_cycle loan_cycle         
       ,s.grp_ref_no
       ,s.grp_nm
       ,s.loan_cycle GROUP_CYCLE
       ,u.login_id CREDIT_OFFICER
       ,t.login_id CREDIT_MANAGER
       ,k.APPl_DT
       ,j.start_dt DAT_ACCT_OPEN
       ,n.last_disbursement_dt DAT_LAST_DISB
       ,j.maturity_dt DAT_OF_MATURITY
       ,v.last_svce_dt LAST_PMT_DATE
       ,v.next_due_dt NEXT_PMT_DATE
       ,v.next_instal_no NEXT_INSTAL_NUMBR
       ,(select sum(repmnt_amt) from  ln_acct_repmnt_event where rec_st not in ('C') and acct_id = j.acct_id and event_type = 'INTEREST' and due_dt = v.next_due_dt) NEXT_INTEREST_DUE
       ,(select sum(repmnt_amt) from  ln_acct_repmnt_event where rec_st not in ('C') and acct_id = j.acct_id and event_type = 'PRINCIPAL' and due_dt = v.next_due_dt) NEXT_PRINC_DUE
       ,j.closed_dt
       ,to_char(j.term_value)||' '||decode(j.term_cd,'M','Months','D','Days','Q','Quarters','Bi-Weekly') TERM
       ,p.crncy_cd
       ,k.approved_limit_amt
       ,j.disbursement_limit
       ,-a.ledger_bal AMT_PRINC_BALANCE
       ,v.SCH_AMT_INEREST
       ,zc.Total_Fees
       ,zc.Processing_Fee
       ,zc.Insurance_Fee
       ,a.acct_rec_st
       ,o.ref_desc ACCT_STAT
       ,zb.guarantor_detls
       ,za.collateral_cat_cd||'-'||za.collateral_ty_desc COL_TYPE
       ,trim(REGEXP_REPLACE(za.p_collateral_desc, '[[:space:]]*', '' )) as p_collateral_desc
       ,za.collateral_cost
       ,za.collateral_market_value
       ,a.delinquent_dt ARR_START_DATE
       ,(case when a.acct_rec_st = 'W' then b.status_effective_dt end) DAT_WRITEOFF
       ,a.princ_arrear
       ,a.delinquent_days
       ,(case when a.delinquent_days between 1 and 7 then (a.LEDGER_BAL*-1) else 0 end) PRINC_ARR_7
       ,(case when a.delinquent_days between 8 and 30 then (a.LEDGER_BAL*-1) else 0 end) PRINC_ARR8_30
       ,(case when a.delinquent_days between 31 and 60 then (a.LEDGER_BAL*-1) else 0 end) PRINC_ARR31_60
       ,(case when a.delinquent_days between 61 and 90 then (a.LEDGER_BAL*-1) else 0 end) PRINC_ARR61_90
       ,(case when a.delinquent_days between 91 and 180 then (a.LEDGER_BAL*-1) else 0 end) PRINC_ARR91_180
       ,(case when a.delinquent_days between 181 and 365 then a.LEDGER_BAL else 0 end) PRINC_ARR180_365
       ,(case when a.delinquent_days >= 366 then (a.LEDGER_BAL*-1) else 0 end) PRINC_ARR366
       ,(case when a.delinquent_days >= 1 then (a.LEDGER_BAL*-1) else 0 end) PAR1    
       ,(case when a.delinquent_days > 30 then (a.LEDGER_BAL*-1) else 0 end) PAR30
       ,nvl(r.margin_rate,0)/100 var_rate
       ,v.tot_int_paid
       ,a.int_arrear           
       ,(select sum(txn_amt) from  loan_account_history where tran_dt = '31 DEC 2020' and contra_acct_no is not null and dr_cr_ind = 'CR' and ln_acct_id = j.acct_id) AMT_PAID_TODAY
       ,nvl(n.calculated_effective_int_rate,r.fixed_rate+(nvl(r.margin_rate,0)/100)) int_rate
       ,(select ABS((LP1.CLEARED_BAL + LP1.UNAPPLIED_FUNDS + LP1.PREPAID_INT_AMT  - LP1.DR_INT_ACCRUED -
       LP1.TOT_LATE_FEE - LP1.TOT_INSURANCE - LP1.TOTAL_ACCRUED_CHARGE)) AS "PAYOFF BAL"
  from v_loan_payoff_bal LP1
  where LP1.ACCT_NO = b.ACCT_NO) as outstanding_bal
       ,(case when g.cust_no in (select distinct cust_no from  sysuser where cust_no is not null) then 'Y' else 'N' end) FLG_STAFF
       ,q.risk_desc
       --,a.provision_bal       

FROM  ln_acct_daily_bal_hist a
join  account b on a.acct_id = b.acct_id
join  business_unit c on c.bu_id = b.main_branch_id
join  org_structure_unit d on d.su_id = c.su_id
join  product e on e.prod_id = b.prod_id
join  product_template f on f.prod_template_id=e.prod_template_id
join  customer g on g.cust_id=b.cust_id
join  customer_cat_ref h on h.ref_key = g.cust_cat
join  customer_type_ref i on i.cust_ty_id = g.cust_ty_id
join  loan_account j on j.acct_id = b.acct_id
join  credit_appl k ON k.appl_id = j.appl_id  
left join reason_ref l on l.rsn_id = k.rsn_id
join (--\*DERIVE CLIENT CYCLE STATISTICS*\
      select a.*
      ,a.orb_cycle-1+b.open_cycle calc_cycle
      from (/*Derive loan_cycle starts*/
            select a.cust_id,a.acct_id,a.acct_no,a.start_dt,b.last_disbursement_dt,a.loan_cycle
            ,row_number() over(partition by a.cust_id order by a.start_dt) orb_cycle
            ,(case when row_number() over(partition by a.cust_id order by a.start_dt) = 1 then decode(a.loan_cycle,0,1,nvl(a.loan_cycle,1)) end) open_cycle
            FROM loan_account a,loan_account_summary b 
            where a.acct_id = b.acct_id and b.last_disbursement_dt is not null) a
      join (/*Derive loan_cycle starting position for first loan*/
           select *
           from (select a.cust_id,a.acct_no,a.start_dt,b.last_disbursement_dt,a.loan_cycle
                ,row_number() over(partition by a.cust_id order by a.start_dt) orb_cycle
                ,(case when row_number() over(partition by a.cust_id order by a.start_dt) = 1 then decode(a.loan_cycle,0,1,nvl(a.loan_cycle,1)) end) open_cycle
                FROM loan_account a,loan_account_summary b 
                where a.acct_id = b.acct_id and b.last_disbursement_dt is not null)
            where orb_cycle = 1
            )b on a.cust_id = b.cust_id 
      )m on m.acct_id = b.acct_id
join  loan_account_summary n on n.acct_id = b.acct_id
join  account_status_ref o on o.ref_key = a.acct_rec_st
join  currency p on p.crncy_id = b.crncy_id
join  loan_account_interest r on r.acct_id = n.acct_id  
left join  risk_ref q on q.risk_id = a.risk_class_id
left join (--derived table to get identification details
            SELECT *
            FROM (select C.IDENT_TY,A.CUST_ID,A.IDENT_NO
                  from  CUSTOMER_identification A
                  JOIN  CUSTOMER_IDENTIFICATION_XREF B ON A.cust_ident_xref_id  = B.CUST_IDENT_XREF_ID
                  JOIN  IDENTIFICATION_TYPE_REF C ON C.IDENT_ID = B.IDENT_ID)
                  PIVOT(MAX(IDENT_NO) FOR IDENT_TY IN (100 "National_IDCard",101 "Association_ID",200 "Passport",201 "Resident_ID",300 "DriverLicense",400 "VotersCard",500 "EmployeeID",600 "Cert_of_Incorpn",700 "Student_ID",800 "BVN",900 "LocalGovt_ID",999 "Others"))
            )z on z.cust_id = g.cust_id
left join  person y on y.cust_id= g.cust_id  
left join  organisation x on x.cust_id = g.cust_id
left join (--\*Industry codes and their sectors*\
          select a.industry_id,a.industry_cd,a.industry_desc sub_industry,b.industry_desc industry,c.industry_desc industry_grp,d.industry_desc sector
          from  industry_ref a
          left join  industry_ref b on a.parent_industry_id = b.industry_id
          left join  industry_ref c on b.parent_industry_id = c.industry_id
          left join  industry_ref d on c.parent_industry_id = d.industry_id
          ) w on w.industry_id = nvl(k.industry_id,g.industry_id)
left join (--\*Derived table to get last service date and next due date*\
          select acct_id,
                 max(case when svce_dt <= '31 DEC 2020' then svce_dt end) last_svce_dt,
                 min(case when due_dt > '31 DEC 2020' then due_dt end) next_due_dt,
                 count(case when due_dt <= '31 DEC 2020' and event_type = 'PRINCIPAL' then due_dt end)+(case when min(case when due_dt > '31 DEC 2020' then due_dt end) is null then null else 1 end) next_instal_no
                ,sum(case when event_type = 'INTEREST' then repmnt_amt end) SCH_AMT_INEREST
                ,sum(case when event_type = 'INTEREST' and due_dt <= '31 DEC 2020'  then amt_paid end) tot_int_paid
          from  ln_acct_repmnt_event
          where rec_st not in ('C')
          group by acct_id
          )v on v.acct_id = b.acct_id
left join  sysuser u on u.sysuser_id = j.primary_officer_id
left join  sysuser t on t.sysuser_id = j.secondary_officer_id
left join (--\*Get Group details*\
          select max(a.start_dt) grp_start_dt,max(a.ref_no) grp_ref_no,max(a.amount) amount,max(a.cr_appl_id) cr_appl_id,max(b.loan_amt) loan_amt,max(c.group_cust_id) group_cust_id
                 ,c.member_cust_id,nvl(d.acct_id,f.acct_id) acct_id,nvl(d.disbursement_limit,f.disbursement_limit) disbursement_limit
                 ,max(e.cust_nm) grp_nm
                 ,max(nvl(d.start_dt,f.start_dt)) ln_start_dt,max(a.loan_cycle) loan_cycle
          from  group_loan a
          join  group_loan_beneficiary b on a.group_loan_id = b.group_loan_id
          join  group_member c on c.group_member_id =b.membership_id
          join  customer e on e.cust_id = a.cust_id
          left join (select x.cust_id,x.acct_id,x.disbursement_limit,x.appl_id,x.start_dt,y.prod_id
                    from  loan_account x
                    join  account y on x.acct_id = y.acct_id
                    )d on d.cust_id = c.member_cust_id and d.disbursement_limit = b.loan_amt and a.prod_id = d.prod_id
                       and (d.appl_id between a.cr_appl_id-150  and a.cr_appl_id+150 or d.start_dt between a.start_dt and a.start_dt+15)
          left join (--\*Derived table to get migrated group loan beneficiaries*\
                    select a.ext_group_loan_id,b.cust_id,d.acct_id,d.disbursement_limit,d.start_dt
                    from  EXT_group_loan_beneficiary a
                    join  customer b on b.swift_short_nm = a.ext_member_cust_id
                    join  account c on c.old_acct_no = a.old_loan_acct_no
                    join  loan_account d on d.acct_id = c.acct_id
                    ) f on f.ext_group_loan_id = a.ref_no and f.cust_id = c.member_cust_id
          where a.rec_st = 'A'
          group by c.member_cust_id,nvl(d.acct_id,f.acct_id),nvl(d.disbursement_limit,f.disbursement_limit)
          )s on s.acct_id = b.acct_id
left join (--\*Derived table for collateral details*\
          select stats_mode(c.collateral_ty_desc) collateral_ty_desc,stats_mode(c.collateral_cat_cd) collateral_cat_cd,stats_mode(a.collateral_desc) collateral_desc
          ,sum(a.collateral_market_value) collateral_market_value,sum(a.collateral_cost) collateral_cost,count(a.collateral_id) cnt
          ,(case when count(a.collateral_id) > 1 then to_char(count(a.collateral_id))||' '||'Multiple collaterals' else stats_mode(a.collateral_desc) end) p_collateral_desc
          ,d.acct_id
          from  collateral a
          join  collateral_lien b on b.collateral_id=a.collateral_id
          join  collateral_type c on c.collateral_ty_id = a.collateral_ty_id
          join  loan_account d on d.appl_id = b.cr_appl_id
          group by d.acct_id
          )za on za.acct_id = j.acct_id
left join (--\*Derived table to get Guarantor details*\
          select c.acct_id,count(*) cnt_guarantors,(case when count(*) > 1 then to_char(count(*))||' '||'Guarantors' else stats_mode(b.cust_no||'-'||b.cust_nm) end) guarantor_detls
          from  credit_appl_guarantor A
          JOIN  CUSTOMER B ON A.GUARANTOR_ID = B.CUST_ID
          JOIN  LOAN_ACCOUNT C ON C.APPL_ID = A.CREDIT_APPL_ID
          group by c.acct_id
          )zb on zb.acct_id = j.acct_id
left join (--\*Derived table to get disbursement feeds*\
          select a.acct_id,sum(a.ptd_amt) Total_Fees
          ,sum(case when lower(b.chrg_desc) like '%insurance%' then a.ptd_amt end) Insurance_Fee
          ,sum(case when lower(b.chrg_desc) like '%application%' then a.ptd_amt end) Application_Fee
          ,sum(case when lower(b.chrg_desc) like '%processing%' then a.ptd_amt end) Processing_Fee
          from  account_charge_summary a
          join  charge b on a.chrg_id = b.chrg_id
          group by a.acct_id
          )zc on zc.acct_id = j.acct_id

where a.process_dt = '31 DEC 2020'
and a.acct_rec_st <> 'L'
--and A.ACCT_ID = '30126'
order by 1 desc
