set linesi 200
set pagesi 100
alter session set nls_date_format='DD-MON-YY HH24:MI:SS';
