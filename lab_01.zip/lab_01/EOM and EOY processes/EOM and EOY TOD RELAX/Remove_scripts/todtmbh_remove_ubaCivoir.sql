delete from tbaadm.dar where dat_ref_type='TM' and schm_code!= 'CACUE' and bank_id ='CI'
/
delete from tbaadm.dar where dat_ref_type='BH' and schm_code!= 'CACUE' and bank_id ='CI'
/
COMMIT

