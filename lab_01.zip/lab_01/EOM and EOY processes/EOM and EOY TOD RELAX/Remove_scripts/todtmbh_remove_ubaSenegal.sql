delete from tbaadm.dar where dat_ref_type='TM' and schm_code!= 'CACUE' AND BANK_ID='SN'
/
delete from tbaadm.dar where dat_ref_type='BH' and schm_code!= 'CACUE' AND BANK_ID='SN'
/
COMMIT

