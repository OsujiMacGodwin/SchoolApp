delete from tbaadm.dar where dat_ref_type='TM' and bank_id =''
/
delete from tbaadm.dar where dat_ref_type='BH' and bank_id =''
/
COMMIT
