delete from tbaadm.dar where dat_ref_type='TM' and schm_code!= 'UNPIN' and bank_id='TD'
/
delete from tbaadm.dar where dat_ref_type='BH' and schm_code!= 'UNPIN' and bank_id='TD'
/
COMMIT

